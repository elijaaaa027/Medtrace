#!/bin/bash
set -euo pipefail

# ==============================================================================
# MedTrace - Production Deployment Script for Google Cloud Run
# Packages workspace into a standard POSIX tar.gz archive and deploys to Cloud Run
# ==============================================================================

SERVICE_NAME="${SERVICE_NAME:-medtrace-0}"
REGION="${REGION:-asia-east1}"
PORT="${PORT:-8080}"
ARCHIVE_NAME="app.tar.gz"

echo "======================================================================"
echo " Packaging MedTrace for Google Cloud Run Deployment"
echo " Service:  ${SERVICE_NAME}"
echo " Region:   ${REGION}"
echo " Port:     ${PORT}"
echo "======================================================================"

# 1. Package the source archive using package-tarball.cjs
node package-tarball.cjs

if [ ! -f "${ARCHIVE_NAME}" ]; then
  echo "Error: ${ARCHIVE_NAME} was not generated!"
  exit 1
fi

ARCHIVE_SIZE=$(ls -lh "${ARCHIVE_NAME}" | awk '{print $5}')
echo "Created valid source tarball: ${ARCHIVE_NAME} (${ARCHIVE_SIZE})"

# 2. Check if gcloud is installed
if command -v gcloud >/dev/null 2>&1; then
  echo "Deploying to Google Cloud Run via gcloud..."
  echo "Running: gcloud run deploy ${SERVICE_NAME} --source=${ARCHIVE_NAME} --region=${REGION} --allow-unauthenticated --port=${PORT}"
  
  gcloud run deploy "${SERVICE_NAME}" \
    --source="${ARCHIVE_NAME}" \
    --region="${REGION}" \
    --allow-unauthenticated \
    --port="${PORT}"
else
  echo ""
  echo "======================================================================"
  echo " Packaging Complete! [${ARCHIVE_NAME}] is ready for Cloud Run."
  echo " To deploy from Google Cloud Shell or your local machine, run:"
  echo ""
  echo "   gcloud run deploy ${SERVICE_NAME} \\"
  echo "     --source=./${ARCHIVE_NAME} \\"
  echo "     --region=${REGION} \\"
  echo "     --allow-unauthenticated \\"
  echo "     --port=${PORT}"
  echo "======================================================================"
fi
