#!/usr/bin/env python3
import os

html_code = r'''<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>MedTrace — Clinical Healthcare & Patient Record Platform</title>
  <meta name="description" content="Comprehensive healthcare platform with multi-language support (English, Tamil, Hindi), phone OTP & biometric authentication, AI Health Concierge with Google Maps Grounding, deep health snapshots, medical reminders, direct hospital booking for Aravind & Meenakshi, itemized receipts, and developed identity profiles." />
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            theme: {
              primary: 'var(--theme-primary)',
              hover: 'var(--theme-primary-hover)'
            }
          }
        }
      }
    };
  </script>
  <style>
    :root {
      --theme-primary: #0D9488;
      --theme-primary-hover: #0F766E;
      --theme-gradient: linear-gradient(135deg, #0D9488 0%, #06B6D4 100%);
      --theme-glow: rgba(13, 148, 136, 0.32);
      --theme-subtle: rgba(13, 148, 136, 0.12);
      --theme-border-hover: rgba(13, 148, 136, 0.55);
    }
    * { transition: background-color 0.2s ease, border-color 0.2s ease, color 0.15s ease; }
    body { font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    .mono { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
    
    .custom-sidebar-scroll::-webkit-scrollbar { width: 6px; }
    .custom-sidebar-scroll::-webkit-scrollbar-track { background: transparent; }
    .custom-sidebar-scroll::-webkit-scrollbar-thumb { background: rgba(148, 163, 184, 0.35); border-radius: 9999px; }
    .custom-sidebar-scroll::-webkit-scrollbar-thumb:hover { background: var(--theme-primary); }

    .hover-poppy {
      transition: all 0.22s cubic-bezier(0.16, 1, 0.3, 1);
    }
    .hover-poppy:hover {
      transform: translateY(-2.5px) scale(1.015);
      box-shadow: 0 12px 28px -5px var(--theme-glow);
      border-color: var(--theme-border-hover);
    }

    .card-gradient-hover {
      transition: all 0.24s cubic-bezier(0.16, 1, 0.3, 1);
      border: 1px solid rgba(226, 232, 240, 0.85);
    }
    html.dark .card-gradient-hover {
      border: 1px solid rgba(51, 65, 85, 0.7);
    }
    .card-gradient-hover:hover {
      transform: translateY(-2px);
      border-color: var(--theme-border-hover) !important;
      box-shadow: 0 14px 30px -8px var(--theme-glow);
    }

    .btn-theme-poppy {
      background: var(--theme-gradient);
      color: #ffffff !important;
      box-shadow: 0 4px 14px 0 var(--theme-glow);
      transition: all 0.2s ease;
    }
    .btn-theme-poppy:hover {
      filter: brightness(1.08);
      transform: translateY(-1.5px) scale(1.02);
      box-shadow: 0 8px 22px 0 var(--theme-glow);
    }
    .badge-theme-subtle {
      background-color: var(--theme-subtle);
      color: var(--theme-primary);
      border: 1px solid var(--theme-border-hover);
    }

    @keyframes pulseGlow {
      0%, 100% { box-shadow: 0 0 0 0 var(--theme-glow); }
      50% { box-shadow: 0 0 0 12px rgba(13, 148, 136, 0); }
    }
    .biometric-pulse {
      animation: pulseGlow 2.2s infinite;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: scale(0.97); }
      to { opacity: 1; transform: scale(1); }
    }
    .animate-fadeIn {
      animation: fadeIn 0.2s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }
    @media print {
      body * { visibility: hidden; }
      #printable-slip, #printable-slip * { visibility: visible; }
      #printable-slip { position: absolute; left: 0; top: 0; width: 100%; }
    }
  </style>
</head>
<body class="bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 min-h-screen antialiased selection:bg-teal-500 selection:text-white">
  <div id="app"></div>

  <script>
    // THEME PALETTES with poppy hover & gradients
    const THEME_PALETTES = {
      aqua: {
        id: 'aqua',
        name: 'Aqua / Teal',
        primary: '#0D9488',
        hover: '#0F766E',
        gradient: 'linear-gradient(135deg, #0D9488 0%, #06B6D4 100%)',
        glow: 'rgba(13, 148, 136, 0.32)',
        subtle: 'rgba(13, 148, 136, 0.12)',
        borderHover: 'rgba(13, 148, 136, 0.55)'
      },
      green: {
        id: 'green',
        name: 'Emerald Green',
        primary: '#059669',
        hover: '#047857',
        gradient: 'linear-gradient(135deg, #059669 0%, #10B981 100%)',
        glow: 'rgba(5, 150, 105, 0.32)',
        subtle: 'rgba(5, 150, 105, 0.12)',
        borderHover: 'rgba(5, 150, 105, 0.55)'
      },
      purple: {
        id: 'purple',
        name: 'Royal Purple',
        primary: '#7C3AED',
        hover: '#6D28D9',
        gradient: 'linear-gradient(135deg, #7C3AED 0%, #A855F7 100%)',
        glow: 'rgba(124, 58, 237, 0.32)',
        subtle: 'rgba(124, 58, 237, 0.12)',
        borderHover: 'rgba(124, 58, 237, 0.55)'
      },
      red: {
        id: 'red',
        name: 'Ruby Crimson',
        primary: '#E11D48',
        hover: '#BE123C',
        gradient: 'linear-gradient(135deg, #E11D48 0%, #F43F5E 100%)',
        glow: 'rgba(225, 29, 72, 0.32)',
        subtle: 'rgba(225, 29, 72, 0.12)',
        borderHover: 'rgba(225, 29, 72, 0.55)'
      },
      yellow: {
        id: 'yellow',
        name: 'Amber Gold',
        primary: '#D97706',
        hover: '#B45309',
        gradient: 'linear-gradient(135deg, #D97706 0%, #F59E0B 100%)',
        glow: 'rgba(217, 119, 6, 0.32)',
        subtle: 'rgba(217, 119, 6, 0.12)',
        borderHover: 'rgba(217, 119, 6, 0.55)'
      },
      blue: {
        id: 'blue',
        name: 'Sapphire Blue',
        primary: '#2563EB',
        hover: '#1D4ED8',
        gradient: 'linear-gradient(135deg, #2563EB 0%, #38BDF8 100%)',
        glow: 'rgba(37, 99, 235, 0.32)',
        subtle: 'rgba(37, 99, 235, 0.12)',
        borderHover: 'rgba(37, 99, 235, 0.55)'
      },
      pink: {
        id: 'pink',
        name: 'Rose Pink',
        primary: '#DB2777',
        hover: '#BE185D',
        gradient: 'linear-gradient(135deg, #DB2777 0%, #F472B6 100%)',
        glow: 'rgba(219, 39, 119, 0.32)',
        subtle: 'rgba(219, 39, 119, 0.12)',
        borderHover: 'rgba(219, 39, 119, 0.55)'
      }
    };
    const THEMES = THEME_PALETTES;

    // COMPREHENSIVE MULTI-LANGUAGE DICTIONARY (Every text translated)
    const I18N = {
      en: {
        code: 'en', nativeLabel: 'English',
        appName: 'MedTrace',
        tagline: 'Clinical Healthcare & Patient Record Platform',
        navDashboard: 'Dashboard',
        navAiChat: 'AI Health Concierge',
        navHealthRecords: 'Health Records',
        navAppointments: 'Appointments & Booking',
        navMedicines: 'Medications & Pills',
        navInsurance: 'Insurance & Claims',
        navGuardian: 'Guardian Network',
        navGuardianOverview: 'Guardian Overview',
        navHealthSnapshot: 'Health Snapshot & Vitals',
        navNearbyHospitals: 'Nearby Hospitals & Maps',
        navReceipts: 'Receipts & Billing',
        navProfile: 'Patient Profile & IDs',
        navSettings: 'Settings & Theme',
        themeColorTitle: 'Accent & Poppy Hover Theme',
        themeColorSubtitle: 'Choose your signature accent color across dark & light modes.',
        bookAppointmentTitle: 'Book Appointment',
        bookAppointmentSubtitle: 'Schedule specialist consultations with instant verification & digital slip.',
        availableHospitalsTab: 'Available Hospitals & Clinics',
        scheduledAppointmentsTab: 'Scheduled Appointments',
        aravindEyeHospital: 'Aravind Eye Hospital',
        meenakshiMission: 'Meenakshi Mission Hospital',
        apolloSpeciality: 'Apollo Speciality Hospitals',
        lalPathlabs: 'Dr. Lal PathLabs Diagnostic Center',
        aravindTagline: 'World-renowned Ophthalmology, Cataract & Retina Care',
        meenakshiTagline: 'Multi-Speciality Tertiary Care, Cardiology & Diabetology',
        directHospitalBooking: 'Direct Booking Portal',
        openAravindBooking: 'Book at Aravind Eye Hospital →',
        openMeenakshiBooking: 'Book at Meenakshi Mission →',
        openApolloBooking: 'Book at Apollo Speciality →',
        openLalBooking: 'Book at Dr. Lal PathLabs →',
        consultationTypeLabel: 'Consultation Mode',
        appointmentDateLabel: 'Appointment Date',
        appointmentTimeLabel: 'Time Slot',
        reasonLabel: 'Reason for Consultation / Symptoms',
        guardianNotifyLabel: 'Sync & notify registered guardian about this booking',
        confirmBookingButton: 'Confirm & Generate Appointment Slip',
        cancelAppointment: 'Cancel Appointment',
        cancelConfirmMessage: 'Are you sure you want to cancel this appointment? Refund will be credited within 24 hours.',
        appointmentCancelledBadge: 'Cancelled',
        appointmentConfirmedBadge: 'Confirmed',
        downloadSlipButton: '📥 Download Slip / Pass',
        viewAppointmentDetails: 'View Full Breakdown & Fee',
        feeStructureTitle: 'Itemized Consultation Fee Structure',
        doctorFee: 'Specialist Consultation Fee',
        registrationFee: 'Hospital Registration & Facility Fee',
        diagnosticAddon: 'Clinical Diagnostics / Pre-check',
        taxesFee: 'GST / Healthcare Service Tax',
        totalGross: 'Total Billable Amount',
        insuranceCoverage: 'Insurance Coverage & Cashless Status',
        insuranceApplicable: 'Cashless Pre-Approved (Star Health Network)',
        insuranceNotCovered: 'Self-Pay / Reimbursement Claim Available',
        patientCopay: 'Patient Out-of-Pocket Co-Pay',
        tokenNumber: 'Hospital Token No',
        digitalPassHeading: 'Official Clinical Token & Consultation Slip',
        medicalRemindersTitle: 'Medical Reminders & Daily Pill Timetable',
        medicalRemindersSubtitle: 'Active alerts for today with timestamped compliance tracking.',
        takenBadge: '✓ Taken',
        markAsTaken: 'Mark Taken',
        pendingDose: 'Pending Due',
        refillAlertTitle: 'Prescription Refill Alerts',
        refillWarning: 'Pills low! Order refill in 2-3 days.',
        timeDue: 'Exact Time Due',
        frequencyLabel: 'Frequency & Instructions',
        prescribedBy: 'Prescribing Physician',
        remainingSupply: 'Supply Remaining',
        addMedication: '+ Add New Prescription',
        foodInstructions: 'Dietary & Food Advisory',
        sideEffects: 'Precautions & Monitored Symptoms',
        healthSnapshotTitle: 'Comprehensive Health Snapshot & Biomarkers',
        healthSnapshotSubtitle: 'Detailed vital readings, clinical parameters, and historical lab ranges.',
        clickToElaborateHint: '💡 Click any metric card for deep clinical elaboration, reference gauges & doctor notes.',
        referenceRange: 'Standard Normal Reference Range',
        doctorAdviceTitle: 'Attending Physician Recommendation',
        historicalLogs: 'Historical Test Trends (Last 3 Readings)',
        closeModal: 'Close Window',
        printOrDownload: 'Print / Save Slip',
        receiptsTitle: 'Clinical Receipts & Itemized Invoices',
        receiptsSubtitle: 'Section 80D tax compliant medical expense ledger with cashless tracking.',
        addReceiptButton: '+ Add New Receipt / Invoice',
        receiptNumber: 'Receipt #',
        providerName: 'Hospital / Pharmacy Provider',
        billDate: 'Billing Date',
        itemizedBreakdown: 'Itemized Services & Medicines',
        subtotalLabel: 'Subtotal',
        cgstLabel: 'CGST (2.5%)',
        sgstLabel: 'SGST (2.5%)',
        insuranceClaimedLabel: 'Insurance Paid (Cashless)',
        patientPaidLabel: 'Net Amount Paid by Patient',
        paymentMethodLabel: 'Payment Mode',
        taxDeductionEligible: 'Income Tax Sec 80D Eligible',
        downloadInvoice: 'Download Tax Invoice',
        guardianPageTitle: 'Guardian & Caregiver Management Network',
        guardianPageSubtitle: 'Emergency authorization, dependent tracking, and 1-click SOS broadcast.',
        primaryGuardian: 'Primary Authorized Guardian',
        secondaryProxy: 'Secondary Medical Proxy',
        dependentTrackerTitle: 'Dependent Health Monitor',
        emergencySosTitle: 'Emergency SOS & Ambulance Dispatch',
        triggerSosButton: '🚨 Trigger Instant SOS to Guardians & 108',
        addNewGuardian: '+ Add Authorized Guardian / Dependent',
        callGuardian: '📞 Call Now',
        whatsappGuardian: '💬 Send Health Sync on WhatsApp',
        profileTitle: 'Comprehensive Patient Profile & Digital Health Dossier',
        profileSubtitle: 'Ayushman Bharat ABHA ID, Aadhaar, PAN Card, and verified clinical demographics.',
        aadhaarCardLabel: 'Aadhaar Card (UIDAI Verified)',
        panCardLabel: 'PAN Card (Income Tax Sec 80D)',
        abhaIdLabel: 'ABHA Health ID (Ayushman Bharat)',
        abhaAddressLabel: 'ABHA Digital Address',
        bloodGroupLabel: 'Blood Group',
        organDonorLabel: 'Organ Donor Status',
        registeredDonor: 'Registered Organ Donor (NOTTO #TN-OD-99214)',
        emergencyContactLabel: 'Primary Caregiver & Emergency Phone',
        insurancePolicyNumber: 'Linked Insurance Policy',
        editProfileButton: '✏️ Edit Profile & Government IDs',
        saveProfileButton: 'Save Profile Changes',
        hidePortalInspector: '✕ Hide Inspector',
        showPortalDetails: '🗂️ Portal Details',
        activePortalInfo: 'Active Portal Inspector',
        quickTelemetry: 'Live Telemetry & Diagnostics',
        switchAccentColor: 'Quick Accent Theme Switcher',
        loginTitle: 'Sign in to MedTrace',
        loginSubtitle: 'Enter your 10-digit mobile number to receive a one-time verification password (OTP).',
        phoneNumberLabel: 'Phone Number',
        phonePlaceholder: '10-digit mobile number (e.g. 9876543210)',
        sendOtpButton: 'Send OTP',
        verifyOtpButton: 'Verify & Continue',
        biometricLoginButton: 'Unlock with Biometrics (Fingerprint / Face)',
        logoutButton: 'Sign Out of MedTrace',
        aiGreeting: 'Hello! I am MedTrace AI, your clinical healthcare concierge powered by Gemini 3.8 Flash with Google Maps Grounding. I can assist with clinical records, laboratory vitals, medication reminders, hospital bookings at Aravind or Meenakshi, insurance claims, or finding 24/7 emergency centers.',
        aiPlaceholder: 'Ask MedTrace AI about health records, medications, symptoms, or nearby clinics...',
        aiSendButton: 'Send Inquiry',
        quickPromptMaps: '🏥 Find 24/7 emergency trauma centers near me',
        quickPromptVitals: '📋 Interpret my health snapshot vitals (BP & HbA1c)',
        quickPromptInsurance: '🛡️ Explain Star Health & HDFC ERGO cashless claims',
        quickPromptMeds: '💊 Medication schedule & drug safety guidelines'
      },
      ta: {
        code: 'ta', nativeLabel: 'தமிழ்',
        appName: 'மெட்டிரேஸ் (MedTrace)',
        tagline: 'மருத்துவ சிகிச்சை & நோயாளி பதிவுகள் தளம்',
        navDashboard: 'முகப்பு பலகை',
        navAiChat: 'AI மருத்துவ உதவியாளர்',
        navHealthRecords: 'மருத்துவ ஆவணங்கள்',
        navAppointments: 'மருத்துவர் முன்பதிவு',
        navMedicines: 'மருந்துகள் & மாத்திரைகள்',
        navInsurance: 'காப்பீடு & கோரிக்கைகள்',
        navGuardian: 'பாதுகாவலர் நெட்வொர்க்',
        navGuardianOverview: 'பாதுகாவலர் மேலோட்டம்',
        navHealthSnapshot: 'உடல்நல அளவீடுகள் (Vitals)',
        navNearbyHospitals: 'அருகிலுள்ள மருத்துவமனைகள்',
        navReceipts: 'கட்டண ரசீதுகள் & பில்கள்',
        navProfile: 'நோயாளி சுயவிவரம் & அரசு ஐடிகள்',
        navSettings: 'அமைப்புகள் & தீம் வண்ணங்கள்',
        themeColorTitle: 'முதன்மை & ஹோவர் நிறம்',
        themeColorSubtitle: 'டார்க் மற்றும் லைட் முறைகளில் உங்களுக்குப் பிடித்த நிறத்தைத் தேர்ந்தெடுக்கவும்.',
        bookAppointmentTitle: 'மருத்துவர் முன்பதிவு',
        bookAppointmentSubtitle: 'உடனடி உறுதிப்படுத்தல் மற்றும் டிஜிட்டல் சீட்டுடன் நிபுணர் சந்திப்புகளை திட்டமிடுங்கள்.',
        availableHospitalsTab: 'கிடைக்கும் மருத்துவமனைகள்',
        scheduledAppointmentsTab: 'முன்பதிவு செய்யப்பட்ட சந்திப்புகள்',
        aravindEyeHospital: 'அரவிந்த் கண் மருத்துவமனை',
        meenakshiMission: 'மீனாட்சி மிஷன் மருத்துவமனை',
        apolloSpeciality: 'அப்பல்லோ சிறப்பு மருத்துவமனை',
        lalPathlabs: 'டாக்டர் லால் பாத்லேப்ஸ் பரிசோதனை மையம்',
        aravindTagline: 'சர்வதேச தரம் வாய்ந்த கண் அறுவைசிகிச்சை & விழித்திரை சிகிச்சை',
        meenakshiTagline: 'பன்னோக்கு சிறப்பு சிகிச்சை, இதயவியல் & நீரிழிவு மையம்',
        directHospitalBooking: 'நேரடி மருத்துவமனை முன்பதிவு தளம்',
        openAravindBooking: 'அரவிந்த் கண் மருத்துவமனையில் முன்பதிவு செய் →',
        openMeenakshiBooking: 'மீனாட்சி மிஷனில் முன்பதிவு செய் →',
        openApolloBooking: 'அப்பல்லோ மருத்துவமனையில் முன்பதிவு செய் →',
        openLalBooking: 'டாக்டர் லால் பாத்லேப்ஸில் முன்பதிவு செய் →',
        consultationTypeLabel: 'சந்திப்பு முறை',
        appointmentDateLabel: 'சந்திப்பு தேதி',
        appointmentTimeLabel: 'நேர இடைவெளி',
        reasonLabel: 'சிகிச்சைக்கான காரணம் / அறிகுறிகள்',
        guardianNotifyLabel: 'பதிவுசெய்யப்பட்ட பாதுகாவலருக்கு இந்த முன்பதிவை உடனே தெரிவிக்கவும்',
        confirmBookingButton: 'உறுதிப்படுத்தி முன்பதிவு சீட்டைப் பெறுக',
        cancelAppointment: 'முன்பதிவை ரத்து செய்',
        cancelConfirmMessage: 'இந்த மருத்துவ சந்திப்பை ரத்து செய்ய விரும்புகிறீர்களா? கட்டணம் 24 மணி நேரத்திற்குள் திருப்பி அளிக்கப்படும்.',
        appointmentCancelledBadge: 'ரத்து செய்யப்பட்டது',
        appointmentConfirmedBadge: 'உறுதியானது',
        downloadSlipButton: '📥 சீட்டைப் பதிவிறக்கு (Download Slip)',
        viewAppointmentDetails: 'முழு கட்டண விவரம் காண்க',
        feeStructureTitle: 'மருத்துவக் கட்டண விவர அறிக்கை',
        doctorFee: 'மருத்துவர் ஆலோசனை கட்டணம்',
        registrationFee: 'மருத்துவமனை பதிவு மற்றும் பராமரிப்பு கட்டணம்',
        diagnosticAddon: 'பரிசோதனை கட்டணம்',
        taxesFee: 'ஜி.எஸ்.டி / சுகாதார வரி',
        totalGross: 'மொத்த கட்டணம்',
        insuranceCoverage: 'காப்பீட்டுத் தகுதி & பணமில்லா நிலை',
        insuranceApplicable: 'பணமில்லா சிகிச்சை அனுமதிக்கப்பட்டது (Star Health)',
        insuranceNotCovered: 'சுய கட்டணம் / திருப்பிச் செலுத்தும் கோரிக்கை',
        patientCopay: 'நோயாளி செலுத்த வேண்டிய தொகை',
        tokenNumber: 'டோக்கன் எண்',
        digitalPassHeading: 'அதிகாரப்பூர்வ மருத்துவ டோக்கன் சீட்டு',
        medicalRemindersTitle: 'மருந்து நினைவூட்டல்கள் & மாத்திரை அட்டவணை',
        medicalRemindersSubtitle: 'இன்றைய நேரடி மருந்து எச்சரிக்கைகள் மற்றும் உட்கொண்ட நிலைக் கண்காணிப்பு.',
        takenBadge: '✓ உட்கொள்ளப்பட்டது',
        markAsTaken: 'சாப்பிட்டேன் எனப் பதிவு செய்',
        pendingDose: 'இன்னும் சாப்பிடவில்லை',
        refillAlertTitle: 'மருந்து தீரும் எச்சரிக்கை (Refill Alert)',
        refillWarning: 'மாத்திரைகள் குறைவு! 2-3 நாட்களில் மருந்து வாங்கவும்.',
        timeDue: 'சாப்பிட வேண்டிய சரியான நேரம்',
        frequencyLabel: 'அளவு & வழிமுறைகள்',
        prescribedBy: 'பரிந்துரைத்த மருத்துவர்',
        remainingSupply: 'இருப்பில் உள்ள மாத்திரைகள்',
        addMedication: '+ புதிய மருந்துச் சீட்டைச் சேர்',
        foodInstructions: 'உணவு முறைகள் மற்றும் எச்சரிக்கைகள்',
        sideEffects: 'பக்க விளைவுகள் & கவனிக்க வேண்டியவை',
        healthSnapshotTitle: 'முழுமையான உடல்நல அளவீடுகள் (Health Snapshot)',
        healthSnapshotSubtitle: 'விரிவான உடலியல் அளவீடுகள், இரத்த சர்க்கரை, பிரஷர் மற்றும் ஆய்வக முடிவுகள்.',
        clickToElaborateHint: '💡 எந்தவொரு அளவீட்டையும் கிளிக் செய்து விரிவான வழிகாட்டுதல், முந்தைய பதிவுகள் மற்றும் மருத்துவர் ஆலோசனையைக் காண்க.',
        referenceRange: 'இயல்பான பொதுவான அளவீட்டு வரம்பு',
        doctorAdviceTitle: 'மருத்துவரின் மருத்துவ ஆலோசனை',
        historicalLogs: 'முந்தைய 3 சோதனைகளின் போக்கு',
        closeModal: 'மூடு',
        printOrDownload: 'அச்சிடு / சேமி',
        receiptsTitle: 'மருத்துவக் கட்டண ரசீதுகள் & பில்கள்',
        receiptsSubtitle: 'வருமான வரி பிரிவு 80D தகுதி பெற்ற டிஜிட்டல் மருத்துவ செலவுக் கணக்கு.',
        addReceiptButton: '+ புதிய ரசீதைச் சேர்',
        receiptNumber: 'ரசீது எண்',
        providerName: 'மருத்துவமனை / மருந்தகம்',
        billDate: 'தேதி',
        itemizedBreakdown: 'சேவைகள் & மருந்துகளின் பட்டியல்',
        subtotalLabel: 'கூட்டுத்தொகை',
        cgstLabel: 'சி.ஜி.எஸ்.டி (2.5%)',
        sgstLabel: 'எஸ்.ஜி.எஸ்.டி (2.5%)',
        insuranceClaimedLabel: 'காப்பீடு செலுத்தியது',
        patientPaidLabel: 'நோயாளி செலுத்திய தொகை',
        paymentMethodLabel: 'பணம் செலுத்திய முறை',
        taxDeductionEligible: 'பிரிவு 80D வரி விலக்குக்குத் தகுதியானது',
        downloadInvoice: 'வரி ரசீதைப் பதிவிறக்கு',
        guardianPageTitle: 'பாதுகாவலர் & பராமரிப்பாளர் நெட்வொர்க்',
        guardianPageSubtitle: 'அவசர சிகிச்சை அங்கீகாரம், முதியோர்/குழந்தைகள் கண்காணிப்பு மற்றும் 108 SOS உதவி.',
        primaryGuardian: 'முதன்மை அதிகாரப்பூர்வ பாதுகாவலர்',
        secondaryProxy: 'இரண்டாம் நிலை மருத்துவப் பொறுப்பாளர்',
        dependentTrackerTitle: 'சார்ந்திருப்போர் உடல்நலக் கண்காணிப்பு',
        emergencySosTitle: 'அவசர SOS & ஆம்புலன்ஸ் அழைப்பு',
        triggerSosButton: '🚨 பாதுகாவலர்களுக்கும் 108-க்கும் உடனடி SOS அனுப்பு',
        addNewGuardian: '+ புதிய பாதுகாவலர் / சார்ந்திருப்பவரைச் சேர்',
        callGuardian: '📞 உடனே அழை',
        whatsappGuardian: '💬 வாட்ஸ்அப்பில் உடல்நல விவரம் அனுப்பு',
        profileTitle: 'நோயாளி சுயவிவரம் & அரசு டிஜிட்டல் ஆவணங்கள்',
        profileSubtitle: 'ஆயுஷ்மான் பாரத் ABHA ID, ஆதார் அட்டை, பான் கார்டு மற்றும் மருத்துவப் பதிவுகள்.',
        aadhaarCardLabel: 'ஆதார் அட்டை (UIDAI சரிபார்க்கப்பட்டது)',
        panCardLabel: 'பான் கார்டு (வருமான வரி 80D சரிபார்க்கப்பட்டது)',
        abhaIdLabel: 'ABHA டிஜிட்டல் ஹெல்த் ஐடி',
        abhaAddressLabel: 'ABHA முகவரி',
        bloodGroupLabel: 'இரத்தப் பிரிவு',
        organDonorLabel: 'உறுப்பு தான நிலை',
        registeredDonor: 'பதிவுசெய்யப்பட்ட உடல் உறுப்பு தான நன்கொடையாளர் (NOTTO #TN-OD-99214)',
        emergencyContactLabel: 'முதன்மை அவசரத் தொடர்பு எண்',
        insurancePolicyNumber: 'இணைக்கப்பட்ட காப்பீட்டுக் கொள்கை',
        editProfileButton: '✏️ சுயவிவரம் & ஐடிகளைத் திருத்து',
        saveProfileButton: 'விவரங்களைச் சேமி',
        hidePortalInspector: '✕ மறை (Hide Inspector)',
        showPortalDetails: '🗂️ போர்டல் விவரங்கள்',
        activePortalInfo: 'செயலில் உள்ள போர்டல் தகவல்',
        quickTelemetry: 'நேரடி அளவீடுகள் & சோதனைகள்',
        switchAccentColor: 'விரைவு வண்ண மாற்றி',
        loginTitle: 'மெட்டிரேஸில் உள்நுழையவும்',
        loginSubtitle: 'உங்கள் 10 இலக்க மொபைல் எண்ணை உள்ளிட்டு OTP பெறவும்.',
        phoneNumberLabel: 'மொபைல் எண்',
        phonePlaceholder: '10 இலக்க எண் (எ.கா. 9876543210)',
        sendOtpButton: 'OTP அனுப்புக',
        verifyOtpButton: 'சரிபார்த்து தொடர்க',
        biometricLoginButton: 'பயோமெட்ரிக் (கைரேகை / முகம்) மூலம் திறக்க',
        logoutButton: 'வெளியேறு (Sign Out)',
        aiGreeting: 'வணக்கம்! நான் மெட்டிரேஸ் AI, உங்கள் மருத்துவ உதவியாளர் (Gemini 3.8 Flash & Google Maps ఆధారமாக). உடல்நலப் பதிவுகள், மாத்திரை நினைவூட்டல்கள், அரவிந்த் அல்லது மீனாட்சி மருத்துவமனை முன்பதிவுகள் மற்றும் காப்பீட்டு விபரங்களில் உங்களுக்கு உதவ முடியும்.',
        aiPlaceholder: 'மருத்துவ ஆவணங்கள், மருந்துகள் அல்லது அறிகுறிகள் பற்றி கேளுங்கள்...',
        aiSendButton: 'அனுப்புக',
        quickPromptMaps: '🏥 அருகிலுள்ள 24/7 அவசர மருத்துவமனைகளைக் கண்டறி',
        quickPromptVitals: '📋 எனது இரத்த அழுத்தம் மற்றும் HbA1c அளவுகளை விளக்கு',
        quickPromptInsurance: '🛡️ ஸ்டார் ஹெல்த் பணமில்லா சிகிச்சை விவரங்களை விளக்கு',
        quickPromptMeds: '💊 மருந்து அட்டவணை மற்றும் பாதுகாப்பு வழிகாட்டுதல்கள்'
      },
      hi: {
        code: 'hi', nativeLabel: 'हिंदी',
        appName: 'मेडट्रेस (MedTrace)',
        tagline: 'क्लिनिकल हेल्थकेयर एवं पेशेंट रिकॉर्ड प्लेटफॉर्म',
        navDashboard: 'डैशबोर्ड',
        navAiChat: 'AI स्वास्थ्य सहायक',
        navHealthRecords: 'स्वास्थ्य रिकॉर्ड्स',
        navAppointments: 'अपॉइंटमेंट्स एवं बुकिंग',
        navMedicines: 'दवाइयां एवं गोलियां',
        navInsurance: 'बीमा एवं क्लेम्स',
        navGuardian: 'अभिभावक नेटवर्क',
        navGuardianOverview: 'अभिभावक अवलोकन',
        navHealthSnapshot: 'हेल्थ स्नैपशॉट एवं वाइटल्स',
        navNearbyHospitals: 'निकटतम अस्पताल एवं मैप्स',
        navReceipts: 'रसीदें एवं बिलिंग',
        navProfile: 'मरीज प्रोफाइल एवं आईडी',
        navSettings: 'सेटिंग्स एवं थीम',
        themeColorTitle: 'एक्सेन्ट एवं होवर रंग',
        themeColorSubtitle: 'डार्क और लाइट मोड में अपना पसंदीदा थीम रंग चुनें।',
        bookAppointmentTitle: 'डॉक्टर अपॉइंटमेंट बुक करें',
        bookAppointmentSubtitle: 'त्वरित पुष्टि एवं डिजिटल पास के साथ विशेषज्ञ डॉक्टरों से परामर्श बुक करें।',
        availableHospitalsTab: 'उपलब्ध अस्पताल एवं क्लीनिक',
        scheduledAppointmentsTab: 'निर्धारित अपॉइंटमेंट्स',
        aravindEyeHospital: 'अरविंद नेत्र अस्पताल (Aravind Eye Hospital)',
        meenakshiMission: 'मीनाक्षी मिशन अस्पताल (Meenakshi Mission)',
        apolloSpeciality: 'अपोलो स्पेशलिटी हॉस्पिटल्स',
        lalPathlabs: 'डॉ. लाल पैथलैब्स डायग्नोस्टिक सेंटर',
        aravindTagline: 'विश्व प्रसिद्ध नेत्र विज्ञान, मोतियाबिंद एवं रेटिना केयर',
        meenakshiTagline: 'मल्टी-स्पेशियलिटी टर्शियरी केयर, कार्डियोलॉजी एवं डायबेटोलॉजी',
        directHospitalBooking: 'सीधा अस्पताल बुकिंग पोर्टल',
        openAravindBooking: 'अरविंद नेत्र अस्पताल में बुक करें →',
        openMeenakshiBooking: 'मीनाक्षी मिशन में बुक करें →',
        openApolloBooking: 'अपोलो स्पेशलिटी में बुक करें →',
        openLalBooking: 'डॉ. लाल पैथलैब्स में बुक करें →',
        consultationTypeLabel: 'परामर्श प्रकार',
        appointmentDateLabel: 'परामर्श तिथि',
        appointmentTimeLabel: 'समय स्लॉट',
        reasonLabel: 'परामर्श का कारण / लक्षण',
        guardianNotifyLabel: 'इस बुकिंग की सूचना पंजीकृत अभिभावक को तुरंत भेजें',
        confirmBookingButton: 'पुष्टि करें और अपॉइंटमेंट स्लिप बनाएं',
        cancelAppointment: 'अपॉइंटमेंट रद्द करें',
        cancelConfirmMessage: 'क्या आप वाकई इस अपॉइंटमेंट को रद्द करना चाहते हैं? धनवापसी 24 घंटे के भीतर संसाधित की जाएगी।',
        appointmentCancelledBadge: 'रद्द किया गया',
        appointmentConfirmedBadge: 'पुष्टित',
        downloadSlipButton: '📥 स्लिप डाउनलोड करें (Download Slip)',
        viewAppointmentDetails: 'पूर्ण विवरण एवं शुल्क संरचना देखें',
        feeStructureTitle: 'मदवार परामर्श शुल्क संरचना',
        doctorFee: 'विशेषज्ञ परामर्श शुल्क',
        registrationFee: 'अस्पताल पंजीकरण एवं सुविधा शुल्क',
        diagnosticAddon: 'क्लिनिकल डायग्नोस्टिक जांच',
        taxesFee: 'जीएसटी / स्वास्थ्य सेवा कर',
        totalGross: 'कुल देय राशि',
        insuranceCoverage: 'बीमा कवरेज एवं कैशलेस स्थिति',
        insuranceApplicable: 'कैशलेस पूर्व-स्वीकृत (Star Health नेटवर्क)',
        insuranceNotCovered: 'स्व-भुगतान / प्रतिपूर्ति क्लेम उपलब्ध',
        patientCopay: 'मरीज द्वारा देय सह-भुगतान',
        tokenNumber: 'अस्पताल टोकन संख्या',
        digitalPassHeading: 'आधिकारिक क्लिनिकल टोकन एवं परामर्श स्लिप',
        medicalRemindersTitle: 'दवा अनुस्मारक एवं दैनिक गोली सारणी',
        medicalRemindersSubtitle: 'सटीक समय और खुराक लेने की स्थिति की लाइव ट्रैकिंग।',
        takenBadge: '✓ ली गई',
        markAsTaken: 'ली गई दर्ज करें',
        pendingDose: 'बाकी खुराक',
        refillAlertTitle: 'दवा रीफिल चेतावनी',
        refillWarning: 'दवाइयां कम हैं! 2-3 दिनों में रीफिल ऑर्डर करें।',
        timeDue: 'लेने का सटीक समय',
        frequencyLabel: 'आवृत्ति एवं निर्देश',
        prescribedBy: 'परामर्शदाता डॉक्टर',
        remainingSupply: 'उपलब्ध गोलियां',
        addMedication: '+ नई दवा जोड़ें',
        foodInstructions: 'आहार एवं भोजन निर्देश',
        sideEffects: 'सावधानियां एवं दुष्प्रभाव',
        healthSnapshotTitle: 'विस्तृत हेल्थ स्नैपशॉट एवं बायोमार्कर्स',
        healthSnapshotSubtitle: 'रक्तचाप, शुगर, एचबीए1सी और महत्वपूर्ण अंगों के परीक्षण स्तर।',
        clickToElaborateHint: '💡 विस्तृत व्याख्या, संदर्भ रेंज और डॉक्टर की सलाह देखने के लिए किसी भी कार्ड पर क्लिक करें।',
        referenceRange: 'मानक सामान्य संदर्भ रेंज',
        doctorAdviceTitle: 'उपचार करने वाले चिकित्सक की सलाह',
        historicalLogs: 'पिछली 3 जांचों का तुलनात्मक रुझान',
        closeModal: 'बंद करें',
        printOrDownload: 'प्रिंट / सुरक्षित करें',
        receiptsTitle: 'क्लिनिकल रसीदें एवं मदवार बिल',
        receiptsSubtitle: 'धारा 80D टैक्स छूट और कैशलेस विवरण युक्त डिजिटल स्वास्थ्य लेजर।',
        addReceiptButton: '+ नई रसीद / इनवॉइस जोड़ें',
        receiptNumber: 'रसीद संख्या',
        providerName: 'अस्पताल / फार्मेसी प्रदाता',
        billDate: 'बिलिंग तिथि',
        itemizedBreakdown: 'सेवाओं एवं दवाओं की सूची',
        subtotalLabel: 'उप-योग',
        cgstLabel: 'सी.जी.एस.टी (2.5%)',
        sgstLabel: 'एस.जी.एस.टी (2.5%)',
        insuranceClaimedLabel: 'बीमा द्वारा भुगतान',
        patientPaidLabel: 'मरीज द्वारा भुगतान की गई शुद्ध राशि',
        paymentMethodLabel: 'भुगतान माध्यम',
        taxDeductionEligible: 'आयकर धारा 80D के तहत छूट योग्य',
        downloadInvoice: 'टैक्स इनवॉइस डाउनलोड करें',
        guardianPageTitle: 'अभिभावक एवं देखभालकर्ता प्रबंधन नेटवर्क',
        guardianPageSubtitle: 'आपातकालीन सहमति, आश्रित स्वास्थ्य ट्रैकिंग और 1-क्लिक एसओएस प्रसारण।',
        primaryGuardian: 'प्राथमिक अधिकृत अभिभावक',
        secondaryProxy: 'द्वितीयक मेडिकल प्रॉक्सी',
        dependentTrackerTitle: 'आश्रित स्वास्थ्य मॉनिटर',
        emergencySosTitle: 'आपातकालीन SOS एवं एम्बुलेंस 108',
        triggerSosButton: '🚨 अभिभावकों और 108 को तत्काल SOS अलर्ट भेजें',
        addNewGuardian: '+ नया अभिभावक / आश्रित जोड़ें',
        callGuardian: '📞 तुरंत कॉल करें',
        whatsappGuardian: '💬 व्हाट्सएप पर स्वास्थ्य रिपोर्ट भेजें',
        profileTitle: 'विस्तृत मरीज प्रोफाइल एवं राष्ट्रीय स्वास्थ्य आईडी',
        profileSubtitle: 'आयुष्मान भारत ABHA ID, आधार, पैन कार्ड और सत्यापित क्लिनिकल विवरण।',
        aadhaarCardLabel: 'आधार कार्ड (UIDAI सत्यापित)',
        panCardLabel: 'पैन कार्ड (आयकर 80D सत्यापित)',
        abhaIdLabel: 'ABHA डिजिटल हेल्थ आईडी',
        abhaAddressLabel: 'ABHA पता',
        bloodGroupLabel: 'रक्त समूह',
        organDonorLabel: 'अंग दाता स्थिति',
        registeredDonor: 'पंजीकृत अंग एवं ऊतक दाता (NOTTO #TN-OD-99214)',
        emergencyContactLabel: 'आपातकालीन संपर्क नंबर',
        insurancePolicyNumber: 'संबद्ध स्वास्थ्य बीमा पॉलिसी',
        editProfileButton: '✏️ प्रोफाइल एवं सरकारी आईडी संपादित करें',
        saveProfileButton: 'परिवर्तन सहेजें',
        hidePortalInspector: '✕ छिपाएं (Hide Inspector)',
        showPortalDetails: '🗂️ पोर्टल विवरण',
        activePortalInfo: 'सक्रिय पोर्टल जानकारी',
        quickTelemetry: 'लाइव टेलीमेट्री एवं निदान',
        switchAccentColor: 'त्वरित थीम रंग परिवर्तक',
        loginTitle: 'मेडट्रेस में साइन इन करें',
        loginSubtitle: 'ओटीपी प्राप्त करने के लिए अपना 10-अंकों का मोबाइल नंबर दर्ज करें।',
        phoneNumberLabel: 'मोबाइल नंबर',
        phonePlaceholder: '10 अंकों का मोबाइल नंबर (जैसे 9876543210)',
        sendOtpButton: 'ओटीपी भेजें',
        verifyOtpButton: 'सत्यापित करें एवं जारी रखें',
        biometricLoginButton: 'बायोमेट्रिक्स (फिंगरप्रिंट / फेस) से खोलें',
        logoutButton: 'साइन आउट करें',
        aiGreeting: 'नमस्ते! मैं मेडट्रेस AI हूँ, जेमिनी 3.8 फ्लैश और गूगल मैप्स ग्राउंडिंग द्वारा संचालित आपका स्वास्थ्य सलाहकार। मैं रिकॉर्ड्स, दवा अनुस्मारक, अरविंद या मीनाक्षी अस्पताल बुकिंग और बीमा दावों में आपकी मदद कर सकता हूँ।',
        aiPlaceholder: 'मेडट्रेस AI से स्वास्थ्य रिकॉर्ड्स, दवाइयों या लक्षणों के बारे में पूछें...',
        aiSendButton: 'भेजें',
        quickPromptMaps: '🏥 मेरे पास 24/7 आपातकालीन अस्पताल खोजें',
        quickPromptVitals: '📋 मेरे बीपी और HbA1c रिपोर्ट का विश्लेषण करें',
        quickPromptInsurance: '🛡️ स्टार हेल्थ कैशलेस क्लेम प्रक्रिया समझाएं',
        quickPromptMeds: '💊 दवा सारणी और सुरक्षा दिशा-निर्देश'
      }
    };

    // DOCTORS LIST WITH DIRECT SPECIALIZATION & HOSPITALS
    const DOCTORS_LIST = [
      {
        id: 'doc-aravind-1',
        name: 'Dr. Aravind Ramanathan',
        degree: 'MBBS, DO, MS (Ophthal), FICO (UK)',
        specialty: 'Chief Cornea & Refractive Cataract Specialist',
        hospital: 'Aravind Eye Hospital, Madurai & Chennai',
        hospitalKey: 'aravind',
        experience: '22 Years Experience',
        avatar: '👨‍⚕️',
        rating: '4.9 ★ (1,420+ reviews)',
        consultationFee: 500,
        registrationFee: 150,
        diagnosticFee: 450,
        insuranceApproved: true,
        availableSlots: ['09:00 AM', '10:30 AM', '11:45 AM', '03:00 PM', '04:30 PM']
      },
      {
        id: 'doc-aravind-2',
        name: 'Dr. N. Venkatesh Prajna',
        degree: 'MBBS, MD (Ophthal), FRCS (Glasg)',
        specialty: 'Director & Senior Vitreo-Retinal Surgeon',
        hospital: 'Aravind Eye Hospital, Madurai',
        hospitalKey: 'aravind',
        experience: '26 Years Experience',
        avatar: '👨‍⚕️',
        rating: '5.0 ★ (2,100+ reviews)',
        consultationFee: 600,
        registrationFee: 150,
        diagnosticFee: 650,
        insuranceApproved: true,
        availableSlots: ['09:30 AM', '11:00 AM', '02:30 PM', '04:00 PM']
      },
      {
        id: 'doc-meenakshi-1',
        name: 'Dr. Meenakshi Sundaram',
        degree: 'MBBS, MD (General Medicine), PG Dip Diab (Boston)',
        specialty: 'Chief Consultant Diabetologist & Metabolic Physician',
        hospital: 'Meenakshi Mission Hospital & Research Centre, Madurai',
        hospitalKey: 'meenakshi',
        experience: '19 Years Experience',
        avatar: '👩‍⚕️',
        rating: '4.9 ★ (1,280+ reviews)',
        consultationFee: 800,
        registrationFee: 200,
        diagnosticFee: 500,
        insuranceApproved: true,
        availableSlots: ['10:00 AM', '11:30 AM', '03:30 PM', '05:00 PM']
      },
      {
        id: 'doc-meenakshi-2',
        name: 'Dr. R. Sivakumar',
        degree: 'MBBS, MD, DM (Cardiology), FACC',
        specialty: 'Head of Interventional Cardiology & Heart Failure Care',
        hospital: 'Meenakshi Mission Hospital & Research Centre, Madurai',
        hospitalKey: 'meenakshi',
        experience: '21 Years Experience',
        avatar: '👨‍⚕️',
        rating: '4.9 ★ (950+ reviews)',
        consultationFee: 900,
        registrationFee: 200,
        diagnosticFee: 850,
        insuranceApproved: true,
        availableSlots: ['09:00 AM', '11:00 AM', '02:00 PM', '04:00 PM']
      },
      {
        id: 'doc-apollo-1',
        name: 'Dr. Shalini Nair',
        degree: 'MBBS, MD, DM (Neurology)',
        specialty: 'Senior Neurologist & Stroke Specialist',
        hospital: 'Apollo Speciality Hospitals, Greams Road',
        hospitalKey: 'apollo',
        experience: '16 Years Experience',
        avatar: '👩‍⚕️',
        rating: '4.9 ★ (720+ reviews)',
        consultationFee: 1200,
        registrationFee: 200,
        diagnosticFee: 600,
        insuranceApproved: true,
        availableSlots: ['10:30 AM', '01:00 PM', '03:30 PM']
      },
      {
        id: 'doc-lal-1',
        name: 'Dr. Priya Chandran',
        degree: 'MBBS, MD (Pathology)',
        specialty: 'Chief Clinical Pathologist & Lab Director',
        hospital: 'Dr. Lal PathLabs & Diagnostic Center',
        hospitalKey: 'lal',
        experience: '14 Years Experience',
        avatar: '👩‍⚕️',
        rating: '4.8 ★ (890+ reviews)',
        consultationFee: 400,
        registrationFee: 100,
        diagnosticFee: 1200,
        insuranceApproved: true,
        availableSlots: ['08:00 AM', '10:00 AM', '12:00 PM', '04:00 PM']
      }
    ];

    // HEALTH SNAPSHOT METRICS METADATA (Detailed range, trend, advice)
    const SNAPSHOT_METRICS_DETAIL = {
      bp: {
        id: 'bp',
        title: { en: 'Blood Pressure', ta: 'இரத்த அழுத்தம்', hi: 'रक्तचाप (Blood Pressure)' },
        value: '118/76 mmHg',
        status: 'Optimal',
        statusColor: 'emerald',
        badge: 'Normal & Stable',
        gaugePercent: 45,
        rangeText: 'Standard: < 120/80 mmHg · Stage 1 HTN: > 130/80 mmHg',
        historical: [
          { date: '2026-10-12', val: '118/76 mmHg', context: 'Morning resting (After Telmisartan 40mg)' },
          { date: '2026-09-28', val: '122/80 mmHg', context: 'Meenakshi Mission routine review' },
          { date: '2026-08-14', val: '120/78 mmHg', context: 'Home digital monitor' }
        ],
        doctorNotes: {
          en: 'Blood pressure is under outstanding control. Continue Telmisartan 40mg once daily in the morning. Keep daily sodium intake below 2,000 mg.',
          ta: 'இரத்த அழுத்தம் மிகச்சிறந்த கட்டுப்பாட்டில் உள்ளது. டெல்மிசார்ட்டன் 40 மிகி மாத்திரையை தொடர்ந்து காலையில் உட்கொள்ளவும். உப்பை உணவில் குறைக்கவும்.',
          hi: 'रक्तचाप पूरी तरह नियंत्रित है। टेल्मीसार्टन 40mg गोली रोजाना सुबह लेते रहें और खाने में नमक की मात्रा सीमित रखें।'
        }
      },
      glucose: {
        id: 'glucose',
        title: { en: 'Fasting Blood Glucose', ta: 'வெறும் வயிற்று இரத்த சர்க்கரை', hi: 'फास्टिंग ब्लड ग्लूकोज' },
        value: '94 mg/dL',
        status: 'Normal',
        statusColor: 'emerald',
        badge: 'Euglycemic Target',
        gaugePercent: 40,
        rangeText: 'Standard Fasting: 70 - 99 mg/dL · Pre-Diabetes: 100 - 125 mg/dL',
        historical: [
          { date: '2026-10-10', val: '94 mg/dL', context: '12-Hour Fasting Lab Draw' },
          { date: '2026-09-15', val: '98 mg/dL', context: 'Home Accu-Chek Glucometer' },
          { date: '2026-08-01', val: '102 mg/dL', context: 'Quarterly Diagnostic Screen' }
        ],
        doctorNotes: {
          en: 'Morning fasting glucose of 94 mg/dL confirms optimal insulin sensitivity. Continue Metformin 500mg twice daily after meals.',
          ta: 'காலையில் 94 mg/dL என்ற சர்க்கரை அளவு மிகவும் சிறப்பானது. மெட்ஃபார்மின் 500 மிகி மருந்தை உணவுடன் தொடரவும்.',
          hi: 'सुबह 94 mg/dL का फास्टिंग ग्लूकोज स्तर उत्कृष्ट नियंत्रण दर्शाता है। भोजन के बाद मेटफॉर्मिन 500mg जारी रखें।'
        }
      },
      hba1c: {
        id: 'hba1c',
        title: { en: 'Glycated Hemoglobin (HbA1c)', ta: 'மூன்று மாத சர்க்கரை அளவு (HbA1c)', hi: 'ग्लाइकेटेड हीमोग्लोबिन (HbA1c)' },
        value: '5.8%',
        status: 'Optimal',
        statusColor: 'teal',
        badge: 'Well Controlled Target (< 6.0%)',
        gaugePercent: 35,
        rangeText: 'Normal: < 5.7% · Prediabetes: 5.7 - 6.4% · Diabetic Target: < 7.0%',
        historical: [
          { date: '2026-09-20', val: '5.8%', context: 'Dr. Lal PathLabs Venous HPLC' },
          { date: '2026-06-12', val: '6.1%', context: 'Quarterly Physician Checkup' },
          { date: '2026-03-05', val: '6.4%', context: 'Initial Diagnosis & Diet Adjustment' }
        ],
        doctorNotes: {
          en: 'HbA1c improved from 6.4% down to 5.8% through consistent lifestyle modification and regular Metformin compliance. Risk of microvascular complications is low.',
          ta: 'உங்கள் மூன்று மாத சராசரி சர்க்கரை அளவு 6.4% இலிருந்து 5.8% ஆகக் குறைந்துள்ளது. நரம்பு மற்றும் கண் பாதிப்பு ஆபத்து மிகக் குறைவு.',
          hi: 'HbA1c 6.4% से घटकर 5.8% हो गया है। आहार और नियमित व्यायाम का पालन करते रहें।'
        }
      },
      heartRate: {
        id: 'heartRate',
        title: { en: 'Resting Heart Rate & ECG', ta: 'இதயத் துடிப்பு & இசிஜி', hi: 'हृदय गति (Heart Rate) एवं ईसीजी' },
        value: '72 bpm',
        status: 'Normal',
        statusColor: 'emerald',
        badge: 'Normal Sinus Rhythm',
        gaugePercent: 50,
        rangeText: 'Normal Resting Adult: 60 - 100 bpm · Bradycardia: < 60 · Tachycardia: > 100',
        historical: [
          { date: '2026-10-12', val: '72 bpm', context: 'Resting 12-Lead ECG Apollo' },
          { date: '2026-09-30', val: '74 bpm', context: 'Post-walk checkup' },
          { date: '2026-08-20', val: '68 bpm', context: 'Morning resting pulse' }
        ],
        doctorNotes: {
          en: 'Resting ECG confirms regular sinus rhythm without ST depression, arrhythmia or premature ectopic beats. Cardiac reserve is solid.',
          ta: 'இதயத் துடிப்பு சீராகவும் நலமாகவும் உள்ளது. எந்தவித ஆபத்தான மாறுதல்களும் இல்லை.',
          hi: 'ईसीजी और हृदय गति सामान्य साइनस रिदम में है। कोई असामान्यता नहीं पाई गई।'
        }
      },
      spo2: {
        id: 'spo2',
        title: { en: 'Blood Oxygen Saturation (SpO2)', ta: 'இரத்த ஆக்ஸிஜன் அளவு (SpO2)', hi: 'रक्त ऑक्सीजन स्तर (SpO2)' },
        value: '99%',
        status: 'Optimal',
        statusColor: 'emerald',
        badge: 'Full Oxygenation',
        gaugePercent: 95,
        rangeText: 'Healthy Range: 95 - 100% · Hypoxemia Warning: < 92%',
        historical: [
          { date: '2026-10-13', val: '99%', context: 'Room air pulse oximeter' },
          { date: '2026-09-25', val: '98%', context: 'Clinic baseline' },
          { date: '2026-08-10', val: '99%', context: 'Annual physical' }
        ],
        doctorNotes: {
          en: 'Arterial oxygenation is robust. Lungs clear to auscultation bilaterally.',
          ta: 'இரத்தத்தில் ஆக்ஸிஜன் அளவு முழுமையான 99% அளவில் ஆரோக்கியமாக உள்ளது.',
          hi: 'रक्त में ऑक्सीजन का स्तर 99% पर पूरी तरह स्वस्थ और सामान्य है।'
        }
      },
      cholesterol: {
        id: 'cholesterol',
        title: { en: 'Lipid Profile (Total Cholesterol)', ta: 'கொலஸ்ட்ரால் பரிசோதனை', hi: 'लिपिड प्रोफाइल (कोलेस्ट्रॉल)' },
        value: '172 mg/dL',
        status: 'Desirable',
        statusColor: 'teal',
        badge: 'Cardioprotective Level (< 200)',
        gaugePercent: 42,
        rangeText: 'Desirable: < 200 mg/dL · Borderline: 200 - 239 mg/dL · High: >= 240 mg/dL',
        historical: [
          { date: '2026-09-14', val: '172 mg/dL (HDL 54, LDL 98)', context: 'Fasting Lipid Panel' },
          { date: '2026-05-10', val: '188 mg/dL', context: 'Pre-Atorvastatin baseline' }
        ],
        doctorNotes: {
          en: 'LDL is nicely kept under 100 mg/dL with Atorvastatin 10mg taken at bedtime. Excellent cardiovascular protection.',
          ta: 'அட்டார்வாஸ்டாடின் மாத்திரை மூலம் கொழுப்பு அளவு 172 mg/dL என்ற பாதுகாப்பான அளவில் உள்ளது.',
          hi: 'एटोरवास्टेटिन 10mg के साथ एलडीएल 100 mg/dL से नीचे बना हुआ है। हृदय स्वास्थ्य सुरक्षित है।'
        }
      },
      kidney: {
        id: 'kidney',
        title: { en: 'Kidney Function (Creatinine & eGFR)', ta: 'சிறுநீரக செயல்பாடு (eGFR)', hi: 'किडनी फंक्शन (क्रिएटिनिन एवं eGFR)' },
        value: '0.9 mg/dL (eGFR 104)',
        status: 'Optimal',
        statusColor: 'emerald',
        badge: 'Normal Glomerular Filtration',
        gaugePercent: 30,
        rangeText: 'Serum Creatinine: 0.7 - 1.2 mg/dL · eGFR: > 90 mL/min/1.73m²',
        historical: [
          { date: '2026-09-14', val: 'Creatinine: 0.9 mg/dL, eGFR: 104', context: 'Comprehensive Metabolic Panel' },
          { date: '2026-04-18', val: 'Creatinine: 0.9 mg/dL, eGFR: 102', context: 'Renal safety panel' }
        ],
        doctorNotes: {
          en: 'Renal function is completely normal. Safe for ongoing Metformin and Telmisartan therapy. Ensure 2.5 to 3 liters of water daily.',
          ta: 'சிறுநீரக செயல்பாடு 100% சீராக உள்ளது. தினமும் 2.5 முதல் 3 லிட்டர் தண்ணீர் குடிக்கவும்.',
          hi: 'गुर्दे की कार्यप्रणाली पूरी तरह सामान्य है। प्रतिदिन 2.5 से 3 लीटर पानी अवश्य पिएं।'
        }
      },
      bmi: {
        id: 'bmi',
        title: { en: 'Body Mass Index (BMI)', ta: 'உடல் நிறை குறியீடு (BMI)', hi: 'बॉडी मास इंडेक्स (BMI)' },
        value: '23.4 kg/m² (74 kg / 178 cm)',
        status: 'Normal',
        statusColor: 'emerald',
        badge: 'Healthy Weight Range',
        gaugePercent: 48,
        rangeText: 'Normal: 18.5 - 24.9 · Overweight: 25.0 - 29.9 · Asian Cutoff: < 23.5',
        historical: [
          { date: '2026-10-10', val: '74.0 kg · BMI 23.4', context: 'Morning scale weigh-in' },
          { date: '2026-08-15', val: '75.2 kg · BMI 23.7', context: 'Clinic checkup' }
        ],
        doctorNotes: {
          en: 'Weight is stable within healthy Asian target cutoff. Maintain 30-40 minutes of brisk aerobic walking 5 times a week.',
          ta: 'உடல் எடை மற்றும் பிஎம்ஐ சரியான விகிதத்தில் உள்ளது. வாரத்திற்கு 5 நாட்கள் நடைப்பயிற்சி செய்யவும்.',
          hi: 'वजन और बीएमआई सामान्य सीमा में है। सप्ताह में 5 दिन 30 मिनट तेज सैर जारी रखें।'
        }
      }
    };

    // APPLICATION GLOBAL REACTIVE STATE
    let state = {
      language: 'en',
      themeColor: 'aqua',
      isDarkMode: false,
      activeUserId: '9840123456',
      currentRoute: 'DASHBOARD',
      appointmentsTab: 'scheduled', // 'scheduled' or 'available_hospitals'
      showRightPortal: true, // Collapsible / Pop-in right panel
      showBookingModal: false,
      bookingHospitalLock: null, // 'aravind' or 'meenakshi' or null
      activeModal: null, // { type: 'SNAPSHOT'|'MEDICINE'|'APPOINTMENT'|'RECEIPT'|'ADD_GUARDIAN'|'ADD_RECEIPT'|'EDIT_PROFILE', data: ... }
      chatModel: 'gemini-3.8-flash',
      userGeoLocation: { lat: 13.0827, lng: 80.2707, city: 'Chennai / Madurai, Tamil Nadu' },
      userBuckets: {}
    };

    let isChatLoading = false;
    let biometricModal = null;

    function loadState() {
      try {
        const saved = localStorage.getItem('medtrace_state_v3');
        if (saved) {
          const parsed = JSON.parse(saved);
          state = Object.assign(state, parsed);
        }
      } catch (e) {
        console.warn('Could not load stored state:', e);
      }
      applyTheme();
    }

    function saveState() {
      try {
        localStorage.setItem('medtrace_state_v3', JSON.stringify(state));
      } catch (e) {
        console.warn('Failed saving state to localStorage:', e);
      }
    }

    function applyTheme() {
      const palette = THEME_PALETTES[state.themeColor] || THEME_PALETTES.aqua;
      const root = document.documentElement;
      root.style.setProperty('--theme-primary', palette.primary);
      root.style.setProperty('--theme-primary-hover', palette.hover);
      root.style.setProperty('--theme-gradient', palette.gradient);
      root.style.setProperty('--theme-glow', palette.glow);
      root.style.setProperty('--theme-subtle', palette.subtle);
      root.style.setProperty('--theme-border-hover', palette.borderHover);

      if (state.isDarkMode) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    }

    function setLanguage(code) {
      state.language = code;
      saveState();
      render();
    }

    function setThemeColor(colorId) {
      if (THEME_PALETTES[colorId]) {
        state.themeColor = colorId;
        applyTheme();
        saveState();
        render();
      }
    }

    function toggleDarkMode() {
      state.isDarkMode = !state.isDarkMode;
      applyTheme();
      saveState();
      render();
    }

    function toggleRightPortal() {
      state.showRightPortal = !state.showRightPortal;
      saveState();
      render();
    }

    function ensureUserBucket(phone) {
      if (!state.userBuckets[phone]) {
        state.userBuckets[phone] = {
          profile: {
            fullName: 'Dr. Ramesh Kumar',
            dateOfBirth: '1982-08-14',
            age: 44,
            gender: 'Male',
            phoneNumber: phone,
            isPhoneVerified: true,
            email: 'ramesh.kumar@medtrace.in',
            address: 'No. 42, Anna Nagar West, Chennai, Tamil Nadu - 600040',
            aadhaarNumber: 'XXXX-XXXX-4892',
            aadhaarVerified: true,
            panNumber: 'ABCDE1234F',
            panVerified: true,
            abhaId: '91-4829-1029-4821',
            abhaAddress: 'rameshkumar@abdm',
            bloodGroup: 'B+ Positive',
            organDonorStatus: 'Registered Organ & Tissue Donor (NOTTO #TN-OD-99214)',
            emergencyContactName: 'Kavitha Ramesh',
            emergencyContactPhone: '9840123456',
            emergencyContactRelation: 'Spouse',
            isProfileCompleted: true
          },
          snapshot: {
            bloodGroup: 'B+ Positive',
            bp: '118/76 mmHg',
            pulse: '72 bpm',
            spo2: '99%',
            fastingSugar: '94 mg/dL',
            hba1c: '5.8%',
            cholesterol: '172 mg/dL',
            bmi: '23.4 kg/m²',
            kidney: 'Creatinine 0.9 mg/dL (eGFR 104)',
            allergies: 'Penicillin (Severe anaphylaxis), Shellfish, Dust Mites',
            recentDiagnosis: 'Type 2 Diabetes Mellitus & Primary Hypertension (Well controlled)',
            vaccinationStatus: 'Fully Vaccinated: COVID-19 Booster (2024), Hepatitis B, Tetanus (2025)'
          },
          medicalReminders: [
            {
              id: 'rem-1',
              medName: 'Metformin Hydrochloride (Glycomet-SR)',
              dosage: '500 mg',
              time: '08:00 AM',
              slot: 'Morning (After Breakfast)',
              instructions: 'Take with warm water immediately after breakfast.',
              taken: true,
              takenTime: '08:15 AM'
            },
            {
              id: 'rem-2',
              medName: 'Telmisartan (Telma)',
              dosage: '40 mg',
              time: '08:00 AM',
              slot: 'Morning (After Breakfast)',
              instructions: 'Take once daily before 9 AM for blood pressure.',
              taken: true,
              takenTime: '08:15 AM'
            },
            {
              id: 'rem-3',
              medName: 'Multivitamin & Zinc Chelate',
              dosage: '1 Capsule',
              time: '01:30 PM',
              slot: 'Afternoon (After Lunch)',
              instructions: 'Take after lunch with water.',
              taken: false,
              takenTime: null
            },
            {
              id: 'rem-4',
              medName: 'Metformin Hydrochloride (Glycomet-SR)',
              dosage: '500 mg',
              time: '08:30 PM',
              slot: 'Night (After Dinner)',
              instructions: 'Evening dose after dinner.',
              taken: false,
              takenTime: null
            },
            {
              id: 'rem-5',
              medName: 'Atorvastatin Calcium (Atorva)',
              dosage: '10 mg',
              time: '10:00 PM',
              slot: 'Bedtime (Before Sleep)',
              instructions: 'Take 30 minutes before bed for lipid control.',
              taken: false,
              takenTime: null
            }
          ],
          medicines: [
            {
              id: 'med-1',
              medicineName: 'Metformin Hydrochloride (Glycomet-SR)',
              salt: 'Metformin Sustained Release',
              dosage: '500 mg',
              exactTime: '08:00 AM & 08:30 PM (After Meals)',
              frequency: 'Twice daily after meals',
              startDate: '2026-01-10',
              endDate: '2026-12-31',
              prescribedBy: 'Dr. Meenakshi Sundaram (MD Diabetology, Meenakshi Mission)',
              instructions: 'Take immediately after breakfast and dinner with warm water.',
              foodAdvisory: 'Take with food to minimize gastric discomfort. Avoid high simple sugars.',
              sideEffects: 'Mild nausea or bloating in rare cases; monitor if persistent.',
              remainingSupply: 6,
              refillNeeded: true,
              takenToday: true,
              takenTodayTime: '08:15 AM',
              status: 'Active',
              visibleToGuardian: true
            },
            {
              id: 'med-2',
              medicineName: 'Telmisartan (Telma)',
              salt: 'Telmisartan Angiotensin II Receptor Blocker',
              dosage: '40 mg',
              exactTime: '08:00 AM (Morning)',
              frequency: 'Once daily morning',
              startDate: '2026-01-10',
              endDate: '2026-12-31',
              prescribedBy: 'Dr. R. Sivakumar (DM Cardiology, Meenakshi Mission)',
              instructions: 'Take every morning with water. Log weekly resting BP.',
              foodAdvisory: 'May be taken with or without food. Avoid potassium salt substitutes.',
              sideEffects: 'Dizziness upon standing rapidly; rise slowly.',
              remainingSupply: 22,
              refillNeeded: false,
              takenToday: true,
              takenTodayTime: '08:15 AM',
              status: 'Active',
              visibleToGuardian: true
            },
            {
              id: 'med-3',
              medicineName: 'Atorvastatin Calcium (Atorva)',
              salt: 'Atorvastatin HMG-CoA Reductase Inhibitor',
              dosage: '10 mg',
              exactTime: '10:00 PM (Bedtime)',
              frequency: 'Once daily before sleep',
              startDate: '2026-01-10',
              endDate: '2026-12-31',
              prescribedBy: 'Dr. Aravind Ramanathan (Apollo Speciality / Aravind Network)',
              instructions: 'Take 30 minutes before sleep. Check lipid panel in 3 months.',
              foodAdvisory: 'Avoid drinking grapefruit juice while on this medication.',
              sideEffects: 'Report unexplained muscle aches or weakness.',
              remainingSupply: 28,
              refillNeeded: false,
              takenToday: false,
              takenTodayTime: null,
              status: 'Active',
              visibleToGuardian: true
            },
            {
              id: 'med-4',
              medicineName: 'Carboxymethylcellulose Eye Drops (Refresh Tears)',
              salt: 'Carboxymethylcellulose Sodium 0.5%',
              dosage: '1 Drop both eyes',
              exactTime: '11:00 AM & 06:00 PM',
              frequency: 'Twice daily for digital eye strain',
              startDate: '2026-02-01',
              endDate: '2026-08-01',
              prescribedBy: 'Dr. N. Venkatesh Prajna (Aravind Eye Hospital)',
              instructions: 'Instill 1 drop in each eye. Keep bottle tip clean and sterile.',
              foodAdvisory: 'Topical ophthalmic drop - no food interaction.',
              sideEffects: 'Temporary mild blurring for 30 seconds after instillation.',
              remainingSupply: 1,
              refillNeeded: false,
              takenToday: false,
              takenTodayTime: null,
              status: 'Active',
              visibleToGuardian: true
            }
          ],
          appointments: [
            {
              id: 'appt-1',
              bookingRef: 'APT-2026-ARV-9412',
              tokenNumber: 'TK-42',
              hospitalKey: 'aravind',
              doctorName: 'Dr. Aravind Ramanathan',
              hospitalOrClinic: 'Aravind Eye Hospital, Madurai',
              department: 'Cornea, Refractive & Cataract Clinic',
              appointmentDate: 'Tomorrow, Oct 15, 2026',
              appointmentTime: '10:30 AM',
              consultationType: 'In-Person Comprehensive Examination',
              reasonForVisit: 'Annual Visual Acuity, Slit-Lamp Bio-microscopy & Glaucoma IOP Screen',
              status: 'Confirmed',
              sharedWithGuardian: true,
              consultationFee: 500,
              registrationFee: 150,
              diagnosticFee: 450,
              taxesFee: 0,
              grossAmount: 1100,
              insuranceApplicable: true,
              insuranceCoveredAmount: 1100,
              patientCopayAmount: 0,
              insurancePolicyName: 'Star Health Comprehensive (Cashless Pre-Auth #ARV-88219)',
              billingStatus: 'Cashless Approved · ₹0 Co-Pay'
            },
            {
              id: 'appt-2',
              bookingRef: 'APT-2026-MNK-6105',
              tokenNumber: 'TK-18',
              hospitalKey: 'meenakshi',
              doctorName: 'Dr. Meenakshi Sundaram',
              hospitalOrClinic: 'Meenakshi Mission Hospital & Research Centre, Madurai',
              department: 'Internal Medicine & Diabetology Department',
              appointmentDate: 'Next Tuesday, Oct 20, 2026',
              appointmentTime: '03:00 PM',
              consultationType: 'In-Person Follow-up & Lab Evaluation',
              reasonForVisit: 'Glycemic Control Review & Quarterly Metabolic Panel Review',
              status: 'Confirmed',
              sharedWithGuardian: true,
              consultationFee: 800,
              registrationFee: 200,
              diagnosticFee: 500,
              taxesFee: 0,
              grossAmount: 1500,
              insuranceApplicable: true,
              insuranceCoveredAmount: 1200,
              patientCopayAmount: 300,
              insurancePolicyName: 'Star Health Network (Cashless Approved #MMH-9921)',
              billingStatus: 'Partially Covered · ₹300 Patient Co-Pay'
            },
            {
              id: 'appt-3',
              bookingRef: 'APT-2026-APL-4410',
              tokenNumber: 'TK-09',
              hospitalKey: 'apollo',
              doctorName: 'Dr. Shalini Nair',
              hospitalOrClinic: 'Apollo Speciality Hospitals, Chennai',
              department: 'Cardiology & Preventive Healthcare',
              appointmentDate: 'Nov 02, 2026',
              appointmentTime: '11:00 AM',
              consultationType: 'HD Video Teleconsultation',
              reasonForVisit: 'Resting ECG Evaluation & Blood Pressure Follow-up',
              status: 'Confirmed',
              sharedWithGuardian: true,
              consultationFee: 1200,
              registrationFee: 200,
              diagnosticFee: 600,
              taxesFee: 0,
              grossAmount: 2000,
              insuranceApplicable: true,
              insuranceCoveredAmount: 1600,
              patientCopayAmount: 400,
              insurancePolicyName: 'Star Health Telehealth Pre-Auth',
              billingStatus: 'Cashless Token Issued'
            }
          ],
          receipts: [
            {
              id: 'rcp-1',
              receiptNumber: 'INV-ARV-2026-8831',
              date: '2026-09-18',
              providerName: 'Aravind Eye Hospital, Madurai',
              taxInvoiceId: 'GSTIN33AAACA1294F1Z8',
              category: 'Ophthalmic Clinic & Vision Diagnostics',
              items: [
                { name: 'Ophthalmologist Consultation (Dr. Aravind)', qty: 1, rate: 500, gst: 0, amount: 500 },
                { name: 'Slit Lamp Bio-microscopy & Refraction', qty: 1, rate: 350, gst: 0, amount: 350 },
                { name: 'Non-Contact Tonometry (IOP Glaucoma)', qty: 1, rate: 250, gst: 0, amount: 250 }
              ],
              subtotal: 1100,
              cgst: 0,
              sgst: 0,
              insuranceClaimed: 1100,
              patientPaid: 0,
              paymentMethod: 'Star Health Cashless Direct TPA',
              status: 'Paid & Cashless Approved',
              section80DEligible: true,
              transactionRef: 'TPA-STAR-881920'
            },
            {
              id: 'rcp-2',
              receiptNumber: 'INV-MMH-2026-7720',
              date: '2026-08-25',
              providerName: 'Meenakshi Mission Hospital & Research Centre',
              taxInvoiceId: 'GSTIN33AACCM8920D1Z2',
              category: 'Internal Medicine & Diagnostic Cardiology',
              items: [
                { name: 'Chief Diabetologist Consultation (Dr. Meenakshi)', qty: 1, rate: 800, gst: 0, amount: 800 },
                { name: '2D Echocardiogram with Color Doppler', qty: 1, rate: 2200, gst: 0, amount: 2200 },
                { name: 'Hospital Facility & Clinical Registration', qty: 1, rate: 200, gst: 0, amount: 200 }
              ],
              subtotal: 3200,
              cgst: 0,
              sgst: 0,
              insuranceClaimed: 2600,
              patientPaid: 600,
              paymentMethod: 'UPI (GPay / 9840123456@okhdfcbank)',
              status: 'Paid & Reimbursable',
              section80DEligible: true,
              transactionRef: 'UPI-MMH-992810'
            },
            {
              id: 'rcp-3',
              receiptNumber: 'INV-APL-2026-4019',
              date: '2026-07-14',
              providerName: 'Apollo Speciality Hospitals, Greams Road',
              taxInvoiceId: 'GSTIN33AAACA4199F1ZU',
              category: 'Cardiology Specialist Diagnostic Consult',
              items: [
                { name: 'Senior Interventional Cardiologist Consult', qty: 1, rate: 1200, gst: 0, amount: 1200 },
                { name: 'Resting 12-Lead Electrocardiogram (ECG)', qty: 1, rate: 650, gst: 0, amount: 650 }
              ],
              subtotal: 1850,
              cgst: 0,
              sgst: 0,
              insuranceClaimed: 1500,
              patientPaid: 350,
              paymentMethod: 'Visa Credit Card (Axis Bank ****9812)',
              status: 'Paid',
              section80DEligible: true,
              transactionRef: 'TXN-APL-882103'
            },
            {
              id: 'rcp-4',
              receiptNumber: 'INV-LAL-2026-3120',
              date: '2026-06-10',
              providerName: 'Dr. Lal PathLabs Diagnostic Center',
              taxInvoiceId: 'GSTIN33AABCL3928E1Z9',
              category: 'Clinical Pathology Diagnostic Panel',
              items: [
                { name: 'Glycated Hemoglobin HPLC (HbA1c)', qty: 1, rate: 650, gst: 0, amount: 650 },
                { name: 'Lipid Profile Comprehensive (Cholesterol, HDL, LDL)', qty: 1, rate: 750, gst: 0, amount: 750 },
                { name: 'Kidney Function Serum Creatinine & eGFR', qty: 1, rate: 250, gst: 0, amount: 250 }
              ],
              subtotal: 1650,
              cgst: 0,
              sgst: 0,
              insuranceClaimed: 0,
              patientPaid: 1650,
              paymentMethod: 'UPI / PhonePe',
              status: 'Paid (Claim Reimbursement Form Filed)',
              section80DEligible: true,
              transactionRef: 'UPI-LAL-771928'
            },
            {
              id: 'rcp-5',
              receiptNumber: 'INV-MED-2026-1928',
              date: '2026-05-18',
              providerName: 'MedPlus Pharmacy & Healthcare',
              taxInvoiceId: 'GSTIN33AACCM4192M1ZK',
              category: 'Prescription Pharmaceuticals',
              items: [
                { name: 'Glycomet-SR 500mg (60 Tablets)', qty: 1, rate: 380, gst: 19, amount: 399 },
                { name: 'Telma 40mg (30 Tablets)', qty: 1, rate: 280, gst: 14, amount: 294 },
                { name: 'Atorva 10mg (30 Tablets)', qty: 1, rate: 390, gst: 19.5, amount: 409.5 },
                { name: 'Refresh Tears Eye Drops (10 ml)', qty: 1, rate: 300, gst: 15, amount: 315 }
              ],
              subtotal: 1350,
              cgst: 33.75,
              sgst: 33.75,
              insuranceClaimed: 0,
              patientPaid: 1417.5,
              paymentMethod: 'Debit Card',
              status: 'Paid',
              section80DEligible: true,
              transactionRef: 'POS-MED-551029'
            },
            {
              id: 'rcp-6',
              receiptNumber: 'INV-DNT-2026-0922',
              date: '2026-04-05',
              providerName: 'Madurai Dental Specialty Clinic & Orthodontics',
              taxInvoiceId: 'GSTIN33AABCM9102P1Z4',
              category: 'Dental Prophylaxis & Preventative Oral Care',
              items: [
                { name: 'Full Mouth Ultrasonic Scaling & Calculus Removal', qty: 1, rate: 1000, gst: 0, amount: 1000 },
                { name: 'Polishing & Topical Fluoride Application', qty: 1, rate: 200, gst: 0, amount: 200 }
              ],
              subtotal: 1200,
              cgst: 0,
              sgst: 0,
              insuranceClaimed: 0,
              patientPaid: 1200,
              paymentMethod: 'Cash / Hospital Counter',
              status: 'Paid',
              section80DEligible: true,
              transactionRef: 'CSH-DNT-2026-44'
            }
          ],
          guardians: [
            {
              id: 'g-1',
              name: 'Kavitha Ramesh',
              relationship: 'Spouse & Primary Caregiver',
              phoneNumber: '9840123456',
              email: 'kavitha.ramesh@medtrace.in',
              isPhoneVerified: true,
              isPrimaryEmergencyContact: true,
              canViewHealthRecords: true,
              canViewAppointments: true,
              canViewMedicines: true,
              canViewInsurance: true,
              canAuthorizeEmergency: true,
              statusBadge: 'Verified & Active',
              notes: 'Primary legal healthcare proxy, authorized to approve emergency hospital procedures.'
            },
            {
              id: 'g-2',
              name: 'Suresh Kumar',
              relationship: 'Brother & Secondary Contact',
              phoneNumber: '9840789012',
              email: 'suresh.kumar@medtrace.in',
              isPhoneVerified: true,
              isPrimaryEmergencyContact: false,
              canViewHealthRecords: false,
              canViewAppointments: true,
              canViewMedicines: true,
              canViewInsurance: false,
              canAuthorizeEmergency: false,
              statusBadge: 'Verified Secondary',
              notes: 'Authorized family liaison for hospital transportation & updates.'
            }
          ],
          dependents: [
            {
              id: 'dep-1',
              name: 'Mr. K. Narayanan',
              relationship: 'Father (Age 78)',
              bloodGroup: 'O+ Positive',
              bp: '130/84 mmHg',
              sugar: '110 mg/dL',
              complianceRate: '94% Pill Adherence',
              attendingDoctor: 'Dr. Meenakshi Sundaram (Meenakshi Mission)',
              nextCheckup: 'Oct 28, 2026',
              notes: 'Geriatric monitoring with automatic caregiver alert sync.'
            }
          ],
          insurancePolicies: [
            {
              id: 'ins-1',
              providerName: 'Star Health and Allied Insurance',
              policyNumber: 'STAR-COMP-2026-981442',
              policyType: 'Comprehensive Family Floater Plan',
              coverageAmount: '₹15,00,000 (INR 15 Lakhs)',
              startDate: '2026-01-01',
              expiryDate: '2027-01-01',
              isActive: true,
              coveredServices: 'Inpatient Hospitalization, Pre/Post Care, Aravind Eye Hospital & Meenakshi Mission Cashless Network, Day Care Surgeries, AYUSH, Annual Full-Body Screen',
              claimInfo: 'Star Health TPA Helpline: 1800-425-2255. Cashless hospital ID card verified.'
            }
          ],
          records: [
            {
              id: 'rec-1',
              fileName: 'comprehensive_metabolic_panel_2026.pdf',
              recordType: 'Clinical Pathology Laboratory Report',
              uploadDate: '2026-09-20',
              fileSize: '1.2 MB',
              appointmentLabel: 'Dr. Lal PathLabs Center',
              sharedWithGuardian: true,
              contentPreview: 'MedTrace Clinical Lab Report\nPatient: Dr. Ramesh Kumar\nFasting Blood Glucose: 94 mg/dL (Normal: 70-99 mg/dL)\nHbA1c: 5.8% (Optimal Target < 6.0%)\nTotal Cholesterol: 172 mg/dL (Normal < 200 mg/dL)\nSerum Creatinine: 0.9 mg/dL (Normal: 0.7-1.2 mg/dL)'
            },
            {
              id: 'rec-2',
              fileName: 'ophthalmic_fundus_aravind_eye.pdf',
              recordType: 'Ophthalmology Diagnostic Slit-Lamp Exam',
              uploadDate: '2026-08-18',
              fileSize: '950 KB',
              appointmentLabel: 'Aravind Eye Hospital, Madurai',
              sharedWithGuardian: true,
              contentPreview: 'Aravind Eye Hospital Clinical Report\nConsultant: Dr. Aravind Ramanathan\nVisual Acuity: OD 6/6, OS 6/6\nIntraocular Pressure (IOP): OD 14 mmHg, OS 15 mmHg (Normal: 10-21 mmHg)\nDilated Fundus Exam: Optic disc sharp, cup-to-disc ratio 0.3, macula clear without diabetic retinopathy.'
            },
            {
              id: 'rec-3',
              fileName: 'resting_ecg_cardiology_apollo.pdf',
              recordType: 'Cardiology Diagnostic Report',
              uploadDate: '2026-07-14',
              fileSize: '840 KB',
              appointmentLabel: 'Apollo Speciality Hospitals',
              sharedWithGuardian: true,
              contentPreview: 'Resting 12-Lead ECG Report\nHeart Rate: 72 bpm\nPR Interval: 148 ms\nQRS Duration: 88 ms\nQTc: 412 ms\nImpression: Normal Sinus Rhythm without ischemic ST-T changes.'
            }
          ],
          chatMessages: [
            {
              id: 'msg-init',
              role: 'model',
              text: 'Hello Dr. Ramesh! I am your MedTrace Clinical Concierge powered by Gemini 3.8 Flash with Google Maps Grounding. I can assist with medication timetables, lab values, hospital visits at Aravind Eye Hospital or Meenakshi Mission, insurance claims, or finding trauma centers.',
              timestamp: '09:00 AM',
              placeLinks: []
            }
          ],
          activityLogs: [
            { id: 'act-1', text: 'Checked into Aravind Eye Hospital portal', category: 'Appointments', time: '10:00 AM' },
            { id: 'act-2', text: 'Logged morning medication Metformin 500mg', category: 'Medications', time: '08:15 AM' }
          ]
        };
      }
      return state.userBuckets[phone];
    }

    function logActivity(text, category) {
      if (!state.activeUserId) return;
      const u = ensureUserBucket(state.activeUserId);
      u.activityLogs.unshift({
        id: 'act-' + Date.now(),
        text: text,
        category: category || 'General',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      });
      if (u.activityLogs.length > 25) u.activityLogs.pop();
    }

    function toggleMedicationDose(medId) {
      if (!state.activeUserId) return;
      const u = ensureUserBucket(state.activeUserId);
      const med = u.medicines.find(m => m.id === medId);
      if (med) {
        med.takenToday = !med.takenToday;
        med.takenTodayTime = med.takenToday ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : null;
        logActivity((med.takenToday ? 'Marked taken: ' : 'Marked pending: ') + med.medicineName, 'Medications');
      }
      // Also sync with medical reminders if matches
      const rem = u.medicalReminders.find(r => r.medName.includes(med.medicineName.split(' ')[0]));
      if (rem) {
        rem.taken = med.takenToday;
        rem.takenTime = med.takenTodayTime;
      }
      saveState();
      render();
    }

    function toggleReminderDose(remId) {
      if (!state.activeUserId) return;
      const u = ensureUserBucket(state.activeUserId);
      const rem = u.medicalReminders.find(r => r.id === remId);
      if (rem) {
        rem.taken = !rem.taken;
        rem.takenTime = rem.taken ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : null;
        logActivity((rem.taken ? 'Checked off dose: ' : 'Unchecked dose: ') + rem.medName, 'Reminders');
      }
      saveState();
      render();
    }

    function cancelAppointment(apptId) {
      const t = I18N[state.language || 'en'] || I18N.en;
      if (!confirm(t.cancelConfirmMessage)) return;
      if (!state.activeUserId) return;
      const u = ensureUserBucket(state.activeUserId);
      const appt = u.appointments.find(a => a.id === apptId);
      if (appt) {
        appt.status = 'Cancelled';
        appt.billingStatus = 'Cancelled · Full Refund Processed';
        logActivity('Cancelled appointment with ' + appt.doctorName, 'Appointments');
        saveState();
        render();
      }
    }

    function openHospitalDirectBooking(hospitalKey) {
      state.bookingHospitalLock = hospitalKey;
      state.showBookingModal = true;
      render();
    }

    function openModal(type, data) {
      state.activeModal = { type, data };
      render();
    }

    function closeModal() {
      state.activeModal = null;
      render();
    }

    function downloadPrintSlip(refCode) {
      const printWin = window.open('', '_blank', 'width=750,height=800');
      if (!printWin) {
        alert('Slip generated for ' + refCode + '! Use browser Print dialog to save PDF.');
        return;
      }
      const u = ensureUserBucket(state.activeUserId);
      const appt = u.appointments.find(a => a.bookingRef === refCode) || u.appointments[0];
      const p = u.profile;
      printWin.document.write(`
        <!doctype html>
        <html>
        <head>
          <title>MedTrace Appointment Slip - ${appt.bookingRef}</title>
          <style>
            body { font-family: Inter, Arial, sans-serif; padding: 30px; color: #1e293b; }
            .header { border-bottom: 2px solid #0D9488; padding-bottom: 15px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }
            .token-box { background: #f0fdfa; border: 2px dashed #0D9488; padding: 15px; text-align: center; border-radius: 12px; margin: 20px 0; }
            .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px; }
            .row { padding: 6px 0; border-bottom: 1px solid #f1f5f9; font-size: 13px; }
            .label { font-weight: bold; color: #64748b; }
            .seal { margin-top: 30px; text-align: right; font-size: 11px; color: #94a3b8; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <h2 style="margin:0;color:#0D9488;">MedTrace Clinical Pass</h2>
              <div style="font-size:12px;color:#64748b;">${appt.hospitalOrClinic}</div>
            </div>
            <div style="text-align:right;">
              <div style="font-size:14px;font-weight:bold;">${appt.bookingRef}</div>
              <div style="font-size:11px;color:#64748b;">Generated: ${new Date().toLocaleDateString()}</div>
            </div>
          </div>
          <div class="token-box">
            <div style="font-size:12px;color:#0D9488;font-weight:bold;text-transform:uppercase;">Priority Consultation Token</div>
            <div style="font-size:36px;font-weight:900;color:#0F766E;">${appt.tokenNumber || 'TK-42'}</div>
            <div style="font-size:12px;color:#64748b;">Present this token at counter 4 on hospital arrival</div>
          </div>
          <div class="grid">
            <div>
              <div class="row"><span class="label">Patient Name:</span> ${p.fullName}</div>
              <div class="row"><span class="label">Mobile Number:</span> +91 ${p.phoneNumber}</div>
              <div class="row"><span class="label">Aadhaar (UIDAI):</span> ${p.aadhaarNumber}</div>
              <div class="row"><span class="label">ABHA Health ID:</span> ${p.abhaId}</div>
            </div>
            <div>
              <div class="row"><span class="label">Doctor:</span> ${appt.doctorName}</div>
              <div class="row"><span class="label">Department:</span> ${appt.department}</div>
              <div class="row"><span class="label">Schedule:</span> ${appt.appointmentDate} at ${appt.appointmentTime}</div>
              <div class="row"><span class="label">Status:</span> ${appt.status}</div>
            </div>
          </div>
          <div style="background:#f8fafc;padding:15px;border-radius:10px;font-size:12px;margin-bottom:20px;">
            <div style="font-weight:bold;margin-bottom:6px;">Fee & Insurance Breakdown:</div>
            <div>Consultation Fee: ₹${appt.consultationFee || 500} · Facility Fee: ₹${appt.registrationFee || 150}</div>
            <div>Insurance: ${appt.insurancePolicyName || 'Star Health Cashless Approved'}</div>
            <div style="font-weight:bold;color:#0D9488;margin-top:6px;">Patient Co-Pay: ₹${appt.patientCopayAmount || 0}</div>
          </div>
          <div class="seal">
            <div>✓ Digitally Verified by MedTrace Hospital Information System</div>
            <div>Official Authorized Clinical Pass · Valid for single patient admission</div>
          </div>
        </body>
        </html>
      `);
      printWin.document.close();
      printWin.focus();
      setTimeout(() => { printWin.print(); }, 400);
    }

    async function sendAiChatMessage(userText) {
      if (!state.activeUserId) return;
      const u = ensureUserBucket(state.activeUserId);
      const text = userText.trim();
      if (!text) return;

      const userMsg = {
        id: 'msg-' + Date.now(),
        role: 'user',
        text: text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        placeLinks: []
      };
      u.chatMessages.push(userMsg);
      isChatLoading = true;
      render();

      try {
        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: u.chatMessages.map(m => ({ role: m.role, text: m.text })),
            userLocation: state.userGeoLocation,
            enableMapsGrounding: true,
            model: state.chatModel || 'gemini-3.8-flash',
            language: state.language || 'en',
            patientContext: {
              fullName: u.profile.fullName,
              bloodGroup: u.snapshot.bloodGroup,
              bp: u.snapshot.bp,
              hba1c: u.snapshot.hba1c,
              allergies: u.snapshot.allergies,
              medications: u.medicines.map(m => m.medicineName + ' ' + m.dosage).join(', '),
              activeInsurance: u.insurancePolicies.filter(p => p.isActive).map(p => p.providerName).join(', '),
              upcomingAppointments: u.appointments.filter(a => a.status === 'Confirmed').map(a => a.doctorName + ' at ' + a.hospitalOrClinic + ' on ' + a.appointmentDate).join('; ')
            }
          })
        });
        const data = await response.json();
        const replyText = data.reply || 'MedTrace clinical guidance is active.';
        const placeLinks = (data.groundingChunks || [])
          .filter(c => c.maps)
          .map(c => ({
            title: c.maps.title || 'Medical Facility',
            address: (c.maps.placeAnswerSources && c.maps.placeAnswerSources.reviewSnippets) ? c.maps.placeAnswerSources.reviewSnippets[0] : 'Healthcare Center',
            uri: c.maps.uri || 'https://www.google.com/maps'
          }));

        u.chatMessages.push({
          id: 'msg-' + Date.now() + 1,
          role: 'model',
          text: replyText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          placeLinks: placeLinks
        });
      } catch (err) {
        console.error('Chat error:', err);
        const t = I18N[state.language || 'en'] || I18N.en;
        u.chatMessages.push({
          id: 'msg-err-' + Date.now(),
          role: 'model',
          text: state.language === 'ta'
            ? 'மெட்டிரேஸ் அவசர தகவல்: உங்கள் வினவல் பெறப்பட்டது. அவசர மருத்துவ உதவிக்கு உடனே 108 அல்லது அரவிந்த்/மீனாட்சி மருத்துவமனையை அணுகவும்.'
            : state.language === 'hi'
            ? 'मेडट्रेस आपातकालीन सूचना: आपका संदेश प्राप्त हुआ। किसी भी तीव्र स्वास्थ्य समस्या के लिए 108/112 या नजदीकी अस्पताल से संपर्क करें।'
            : 'MedTrace Clinical Notice: Please consult a licensed physician or dial 112/108 for acute emergency conditions.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          placeLinks: [
            {
              title: 'Nearby 24/7 Hospitals on Google Maps',
              address: 'Tap to view accredited medical centers in your vicinity',
              uri: 'https://www.google.com/maps/search/hospitals+near+me'
            }
          ]
        });
      } finally {
        isChatLoading = false;
        saveState();
        render();
        const box = document.getElementById('chat-thread-container');
        if (box) box.scrollTop = box.scrollHeight;
      }
    }

    // TOP LANGUAGE BAR
    function renderLanguageBar(t) {
      return `
        <div class="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-2xl border border-slate-200 dark:border-slate-700">
          <button onclick="setLanguage('en')" class="px-2.5 py-1 rounded-xl text-xs font-bold transition-all ${state.language === 'en' ? 'btn-theme-poppy' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'}">
            English
          </button>
          <button onclick="setLanguage('ta')" class="px-2.5 py-1 rounded-xl text-xs font-bold transition-all ${state.language === 'ta' ? 'btn-theme-poppy' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'}">
            தமிழ்
          </button>
          <button onclick="setLanguage('hi')" class="px-2.5 py-1 rounded-xl text-xs font-bold transition-all ${state.language === 'hi' ? 'btn-theme-poppy' : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'}">
            हिंदी
          </button>
        </div>
      `;
    }

    // MAIN RENDER ENTRY POINT
    function render() {
      const app = document.getElementById('app');
      if (!app) return;
      const t = I18N[state.language || 'en'] || I18N.en;

      if (!state.activeUserId) {
        renderAuthScreen(app, t);
        return;
      }

      const u = ensureUserBucket(state.activeUserId);
      const navItems = [
        { id: 'DASHBOARD', label: t.navDashboard, icon: '📊' },
        { id: 'AI_CHAT', label: t.navAiChat, icon: '🤖', badge: 'Gemini + Maps' },
        { id: 'HEALTH_SNAPSHOT', label: t.navHealthSnapshot, icon: '🩺' },
        { id: 'APPOINTMENTS', label: t.navAppointments, icon: '📅', count: u.appointments.length },
        { id: 'MEDICINES', label: t.navMedicines, icon: '💊', count: u.medicines.length },
        { id: 'RECEIPTS', label: t.navReceipts, icon: '🧾', count: u.receipts.length },
        { id: 'INSURANCE', label: t.navInsurance, icon: '🛡️', badge: 'Active' },
        { id: 'GUARDIAN', label: t.navGuardian, icon: '👥', count: u.guardians.length },
        { id: 'HEALTH_RECORDS', label: t.navHealthRecords, icon: '📄', count: u.records.length },
        { id: 'NEARBY_HOSPITALS', label: t.navNearbyHospitals, icon: '📍' },
        { id: 'PROFILE', label: t.navProfile, icon: '👤' },
        { id: 'SETTINGS', label: t.navSettings, icon: '⚙️' }
      ];

      app.innerHTML = `
        <div class="min-h-screen flex flex-col lg:flex-row">
          <!-- LARGER SCROLLABLE LEFT GUI SIDEBAR -->
          <aside class="w-full lg:w-72 xl:w-80 bg-white dark:bg-slate-900 border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between shrink-0 lg:h-screen lg:sticky lg:top-0 lg:overflow-y-auto custom-sidebar-scroll shadow-sm">
            <div class="space-y-5">
              <!-- Brand Header -->
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-3">
                  <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-white text-xl font-black btn-theme-poppy">
                    ⚕️
                  </div>
                  <div>
                    <h1 class="text-base font-extrabold tracking-tight">${t.appName}</h1>
                    <p class="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">${t.tagline.split('&')[0]}</p>
                  </div>
                </div>
                <button onclick="toggleDarkMode()" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover-poppy text-xs" title="Toggle Dark/Light Mode">
                  ${state.isDarkMode ? '☀️' : '🌙'}
                </button>
              </div>

              <!-- Language Selector in Sidebar -->
              <div class="flex justify-between items-center">
                <span class="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Language</span>
                ${renderLanguageBar(t)}
              </div>

              <!-- Navigation Menu with Poppy Gradients -->
              <nav class="space-y-1">
                ${navItems.map(item => {
                  const isActive = state.currentRoute === item.id;
                  return `
                    <button onclick="state.currentRoute='${item.id}';saveState();render();" 
                      class="w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all hover-poppy ${isActive ? 'btn-theme-poppy font-extrabold shadow-sm' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/80'}">
                      <div class="flex items-center gap-3 truncate">
                        <span class="text-base">${item.icon}</span>
                        <span class="truncate">${item.label}</span>
                      </div>
                      <div class="flex items-center gap-1.5 shrink-0">
                        ${item.badge ? `<span class="text-[10px] font-bold px-2 py-0.5 rounded-full ${isActive ? 'bg-white/20 text-white' : 'badge-theme-subtle'}">${item.badge}</span>` : ''}
                        ${item.count !== undefined ? `<span class="text-[10px] font-mono px-1.5 py-0.5 rounded-md ${isActive ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-500'}">${item.count}</span>` : ''}
                      </div>
                    </button>
                  `;
                }).join('')}
              </nav>

              <!-- Quick Medical Reminders Widget in Sidebar -->
              <div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 space-y-2">
                <div class="flex items-center justify-between">
                  <span class="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Pill Alarms Today</span>
                  <span class="text-[10px] font-bold text-emerald-600">${u.medicalReminders.filter(r => r.taken).length}/${u.medicalReminders.length} Done</span>
                </div>
                <div class="space-y-1">
                  ${u.medicalReminders.slice(0, 2).map(r => `
                    <div class="flex items-center justify-between text-[11px] p-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
                      <div class="truncate font-semibold">${r.medName.split(' ')[0]} (${r.time})</div>
                      <button onclick="toggleReminderDose('${r.id}')" class="text-xs ${r.taken ? 'text-emerald-600 font-black' : 'text-slate-400 hover:text-slate-700'}">
                        ${r.taken ? '✓' : '○'}
                      </button>
                    </div>
                  `).join('')}
                </div>
              </div>
            </div>

            <!-- Sidebar Footer User Card -->
            <div class="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
              <div class="flex items-center gap-2.5 truncate cursor-pointer" onclick="state.currentRoute='PROFILE';saveState();render();">
                <div class="w-9 h-9 rounded-xl flex items-center justify-center font-black text-sm btn-theme-poppy shrink-0">
                  👨‍⚕️
                </div>
                <div class="truncate">
                  <div class="font-extrabold text-xs truncate">${u.profile.fullName}</div>
                  <div class="text-[10px] text-slate-400 font-mono">+91 ${state.activeUserId}</div>
                </div>
              </div>
              <button onclick="state.activeUserId=null;saveState();render();" class="p-2 rounded-xl text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 text-xs" title="${t.logoutButton}">
                🚪
              </button>
            </div>
          </aside>

          <!-- MAIN CONTENT VIEWPORT -->
          <main class="flex-1 min-w-0 p-4 md:p-8 space-y-6 overflow-y-auto">
            <!-- Top Bar with Hide/Pop Inspector Toggle -->
            <div class="flex items-center justify-between gap-4 pb-2 border-b border-slate-100 dark:border-slate-800">
              <div class="flex items-center gap-2">
                <span class="text-xs font-bold text-slate-400 uppercase tracking-wider">${t.appName} &gt;</span>
                <span class="text-xs font-extrabold" style="color: var(--theme-primary);">${navItems.find(x => x.id === state.currentRoute)?.label || state.currentRoute}</span>
              </div>
              <div class="flex items-center gap-2">
                ${!state.showRightPortal ? `
                  <button onclick="toggleRightPortal()" class="px-3.5 py-1.5 rounded-2xl btn-theme-poppy text-xs font-extrabold flex items-center gap-1.5 shadow-sm">
                    <span>${t.showPortalDetails}</span>
                    <span class="w-2 h-2 rounded-full bg-white animate-pulse"></span>
                  </button>
                ` : `
                  <button onclick="toggleRightPortal()" class="px-3 py-1.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white">
                    ${t.hidePortalInspector}
                  </button>
                `}
              </div>
            </div>

            <!-- Active Route Screen -->
            ${renderActiveRouteScreen(state.currentRoute, u, t)}
          </main>

          <!-- RIGHT-SIDE PORTAL INSPECTOR (Hide & Pop Capability) -->
          ${state.showRightPortal ? renderRightPortalInspector(state.currentRoute, u, t) : ''}
        </div>

        <!-- MODAL OVERLAYS (Health Detail, Medicine Detail, Appointment Fee Detail, Add Guardian, Booking Modal) -->
        ${renderActiveModal(u, t)}
        ${state.showBookingModal ? renderBookingModal(t) : ''}
        ${biometricModal ? renderBiometricDialog(t) : ''}
      `;
    }

    // RIGHT-SIDE PORTAL INSPECTOR
    function renderRightPortalInspector(route, u, t) {
      const p = u.profile || {};
      const s = u.snapshot || {};
      const lang = state.language || 'en';

      const portalMetadata = {
        DASHBOARD: {
          name: t.navDashboard,
          icon: '📊',
          badge: 'Clinical Hub',
          desc: {
            en: 'Holistic clinical dashboard aggregating vital metrics, upcoming doctor visits, active medications, insurance coverage, and latest activity logs.',
            ta: 'முக்கிய உடல்நல அளவீடுகள், வரவிருக்கும் சந்திப்புகள், மருந்துகள் மற்றும் காப்பீட்டுத் தகவல்களின் ஒட்டுமொத்தப் பார்வை.',
            hi: 'प्रमुख स्वास्थ्य मेट्रिक्स, आगामी डॉक्टर विज़िट, दवाओं और बीमा कवरेज का संपूर्ण अवलोकन।'
          },
          stats: [
            { label: 'Next Visit', val: u.appointments.find(a => a.status !== 'Cancelled')?.appointmentDate || 'No upcoming' },
            { label: 'Active Meds', val: `${u.medicines.filter(m => m.status === 'Active').length} Prescriptions` },
            { label: 'Health Records', val: `${u.records.length} Documents` },
            { label: 'Active Insurance', val: 'Star Health (₹15L)' }
          ]
        },
        AI_CHAT: {
          name: t.navAiChat,
          icon: '🤖',
          badge: 'Gemini + Maps',
          desc: {
            en: 'AI Clinical Concierge powered by Gemini 3.8 Flash with Google Maps Grounding. Real clinical guidance in your active language.',
            ta: 'ஜெமினி 3.8 ஃபிளாஷ் மற்றும் கூகுள் மேப்ஸ் ఆధారமாக இயங்கும் நேரடி மருத்துவ ஆலோசனை தளம்.',
            hi: 'जेमिनी 3.8 फ्लैश और गूगल मैप्स ग्राउंडिंग द्वारा संचालित आपका एआई स्वास्थ्य सहायक।'
          },
          stats: [
            { label: 'AI Model', val: state.chatModel },
            { label: 'Grounding', val: 'Google Maps Places API' },
            { label: 'Language', val: state.language.toUpperCase() },
            { label: 'Latency', val: '~480ms' }
          ]
        },
        HEALTH_SNAPSHOT: {
          name: t.navHealthSnapshot,
          icon: '🩺',
          badge: 'Live Vitals',
          desc: {
            en: 'Deep clinical snapshot including Blood Pressure, Glucose, HbA1c, Lipid panel, Kidney eGFR, and BMI with interactive historical trends.',
            ta: 'இரத்த அழுத்தம், சர்க்கரை, கொழுப்பு, மற்றும் சிறுநீரக செயல்பாடுகளின் முழுமையான ஆய்வு அளவீடுகள்.',
            hi: 'रक्तचाप, ग्लूकोज, एचबीए1सी, लिपिड और किडनी स्वास्थ्य की लाइव एवं तुलनात्मक रिपोर्ट।'
          },
          stats: [
            { label: 'BP Status', val: '118/76 (Optimal)' },
            { label: 'HbA1c Target', val: '5.8% (Controlled)' },
            { label: 'Lipid Health', val: '172 mg/dL (Normal)' },
            { label: 'Kidney eGFR', val: '104 mL/min' }
          ]
        },
        APPOINTMENTS: {
          name: t.navAppointments,
          icon: '📅',
          badge: 'Direct Booking',
          desc: {
            en: 'Direct hospital booking portals for Aravind Eye Hospital and Meenakshi Mission Hospital, complete with cancellation and digital slips.',
            ta: 'அரவிந்த் கண் மருத்துவமனை மற்றும் மீனாட்சி மிஷன் மருத்துவமனைகளுக்கான நேரடி முன்பதிவு தளம்.',
            hi: 'अरविंद नेत्र अस्पताल और मीनाक्षी मिशन अस्पताल हेतु समर्पित सीधी बुकिंग और पास।'
          },
          stats: [
            { label: 'Confirmed', val: `${u.appointments.filter(a => a.status === 'Confirmed').length} Slots` },
            { label: 'Direct Portals', val: 'Aravind & Meenakshi' },
            { label: 'Slip Status', val: 'Print Ready' },
            { label: 'Cashless', val: 'Pre-Approved' }
          ]
        },
        MEDICINES: {
          name: t.navMedicines,
          icon: '💊',
          badge: 'Pill Compliance',
          desc: {
            en: 'Active prescription manager with exact intake times, taken/pending tick marks, food advisories, and pharmacy refill warnings.',
            ta: 'மாத்திரைகள் எடுக்கும் நேரம், சாப்பிட்ட நிலைக் குறியீடு மற்றும் மருந்து தீரும் எச்சரிக்கைகள்.',
            hi: 'सटीक समय, ली गई/बाकी खुराक के टिक मार्क और रीफिल चेतावनियों के साथ दवा प्रबंधन।'
          },
          stats: [
            { label: 'Daily Doses', val: '4 Scheduled' },
            { label: 'Morning Completed', val: '2/2 Taken ✓' },
            { label: 'Refill Warning', val: 'Metformin (6 left)' },
            { label: 'Compliance', val: '100% On-time' }
          ]
        },
        RECEIPTS: {
          name: t.navReceipts,
          icon: '🧾',
          badge: 'Tax / Claims',
          desc: {
            en: 'Itemized clinical billing and invoices for consultation, diagnostics, and pharmacy with Income Tax Sec 80D compliance tracking.',
            ta: 'மருத்துவக் கட்டண ரசீதுகள், மருந்துச் சீட்டுகள் மற்றும் 80D வரி விலக்கு ஆவணங்கள்.',
            hi: 'मदवार मेडिकल रसीदें, टैक्स इनवॉइस और आयकर धारा 80D डिडक्शन ट्रैकिंग।'
          },
          stats: [
            { label: 'Total Invoices', val: `${u.receipts.length} Bills` },
            { label: '80D Deductible', val: '100% Eligible' },
            { label: 'Cashless Direct', val: '₹5,200 Settled' },
            { label: 'Copay Logged', val: '₹950 via UPI' }
          ]
        },
        GUARDIAN: {
          name: t.navGuardian,
          icon: '👥',
          badge: 'Safety Net',
          desc: {
            en: 'Caregiver network featuring primary legal proxies, dependent health monitoring, and 1-click 108 SOS dispatch.',
            ta: 'பாதுகாவலர் நெட்வொர்க், முதியோர்/சார்ந்திருப்போர் கண்காணிப்பு மற்றும் அவசர SOS அழைப்பு.',
            hi: 'देखभालकर्ता नेटवर्क, आश्रित स्वास्थ्य ट्रैकिंग और 108 आपातकालीन एसओएस प्रसारण।'
          },
          stats: [
            { label: 'Primary Proxy', val: 'Kavitha Ramesh' },
            { label: 'Dependents', val: '1 Monitored' },
            { label: 'SOS Link', val: '108 / 112 Active' },
            { label: 'Permissions', val: 'Full Caregiver' }
          ]
        },
        PROFILE: {
          name: t.navProfile,
          icon: '👤',
          badge: 'ABHA & IDs',
          desc: {
            en: 'Expansive patient identity featuring Ayushman Bharat ABHA Health ID, UIDAI verified Aadhaar, PAN card, and digital health pass.',
            ta: 'ஆயுஷ்மான் பாரத் ABHA ஐடி, ஆதார், பான் கார்டு மற்றும் டிஜிட்டல் ஹெல்த் கார்டு சுயவிவரம்.',
            hi: 'आयुष्मान भारत आभा आईडी, आधार, पैन कार्ड और डिजिटल हेल्थ कार्ड का संपूर्ण प्रोफाइल।'
          },
          stats: [
            { label: 'Aadhaar Status', val: 'UIDAI Verified ✓' },
            { label: 'PAN Card', val: '80D Linked ✓' },
            { label: 'ABHA ID', val: 'Active @abdm' },
            { label: 'Organ Donor', val: 'NOTTO Registered' }
          ]
        },
        INSURANCE: {
          name: t.navInsurance,
          icon: '🛡️',
          badge: 'Cashless TPAs',
          desc: {
            en: 'Active insurance policies with pre-approved cashless network hospital integration across Star Health & HDFC ERGO.',
            ta: 'ஸ்டார் ஹெல்த் மற்றும் ஹெச்டிஎஃப்சி எர்கோ பணமில்லா சிகிச்சை நெட்வொர்க்.',
            hi: 'स्टार हेल्थ और एचडीएफसी एर्गो के साथ सक्रिय कैशलेस अस्पताल नेटवर्क।'
          },
          stats: [
            { label: 'Policy Cover', val: '₹15,00,000' },
            { label: 'Network Hospitals', val: '14,000+ Centers' },
            { label: 'TPA Status', val: 'Cashless Active' },
            { label: 'Claim Approval', val: 'Instant Digital' }
          ]
        },
        SETTINGS: {
          name: t.navSettings,
          icon: '⚙️',
          badge: 'Personalize',
          desc: {
            en: 'Configure display themes, signature poppy hover accents, language preferences, and biometric security keys.',
            ta: 'தீம் நிறங்கள், மொழித் தேர்வுகள் மற்றும் பயோமெட்ரிக் பாதுகாப்பு அமைப்புகளை மாற்றவும்.',
            hi: 'थीम रंग, सिग्नेचर होवर इफेक्ट्स, भाषा और बायोमेट्रिक सेटिंग्स अनुकूलित करें।'
          },
          stats: [
            { label: 'Active Accent', val: (THEME_PALETTES[state.themeColor] || THEME_PALETTES.aqua).name },
            { label: 'Dark Mode', val: state.isDarkMode ? 'Active' : 'Light Mode' },
            { label: 'Session Phone', val: `+91 ${state.activeUserId}` },
            { label: 'Storage', val: 'Local Encrypted' }
          ]
        }
      };

      const info = portalMetadata[route] || portalMetadata.DASHBOARD;
      const localizedDesc = info.desc[lang] || info.desc.en;

      return `
        <aside class="w-full lg:w-72 xl:w-80 bg-white dark:bg-slate-900 border-t lg:border-t-0 lg:border-l border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between shrink-0 lg:h-screen lg:sticky lg:top-0 lg:overflow-y-auto custom-sidebar-scroll shadow-sm">
          <div class="space-y-5">
            <!-- Inspector Header with Hide Button -->
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div class="flex items-center gap-2">
                <span class="text-lg">${info.icon}</span>
                <div>
                  <h3 class="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-200">${info.name}</h3>
                  <span class="text-[10px] font-bold text-slate-400">${t.activePortalInfo}</span>
                </div>
              </div>
              <button onclick="toggleRightPortal()" class="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-white text-xs font-bold" title="${t.hidePortalInspector}">
                ✕
              </button>
            </div>

            <!-- Portal Badge & Summary -->
            <div class="p-4 rounded-2xl bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-800/50 dark:to-slate-800/20 border border-slate-200 dark:border-slate-800 space-y-2">
              <div class="flex items-center justify-between">
                <span class="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">Portal Scope</span>
                <span class="text-[10px] font-extrabold px-2 py-0.5 rounded-full btn-theme-poppy text-white">${info.badge}</span>
              </div>
              <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">${localizedDesc}</p>
            </div>

            <!-- Portal Telemetry Stats Grid -->
            <div class="space-y-2">
              <div class="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">${t.quickTelemetry}</div>
              <div class="grid grid-cols-2 gap-2 text-xs">
                ${info.stats.map(st => `
                  <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <div class="text-[9px] text-slate-400 uppercase font-bold truncate">${st.label}</div>
                    <div class="font-extrabold text-xs mt-0.5 truncate" style="color: var(--theme-primary);">${st.val}</div>
                  </div>
                `).join('')}
              </div>
            </div>

            <!-- Quick Theme Switcher in Right Inspector -->
            <div class="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div class="flex items-center justify-between">
                <span class="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">${t.switchAccentColor}</span>
                <span class="text-[10px] font-bold" style="color: var(--theme-primary);">${(THEME_PALETTES[state.themeColor] || THEME_PALETTES.aqua).name}</span>
              </div>
              <div class="flex flex-wrap gap-1.5">
                ${Object.keys(THEME_PALETTES).map(k => {
                  const pal = THEME_PALETTES[k];
                  const isCur = state.themeColor === k;
                  return `
                    <button onclick="setThemeColor('${k}')" 
                      class="w-6 h-6 rounded-full transition-transform hover:scale-110 flex items-center justify-center ${isCur ? 'ring-2 ring-offset-2 ring-slate-900 dark:ring-white scale-110' : ''}" 
                      style="background-color: ${pal.primary};" 
                      title="${pal.name}">
                      ${isCur ? '✓' : ''}
                    </button>
                  `;
                }).join('')}
              </div>
            </div>

            <!-- Quick Direct Hospital Links -->
            <div class="p-3.5 rounded-2xl bg-teal-500/10 border border-teal-500/20 space-y-2 text-xs">
              <div class="font-bold text-[11px] text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                <span>🏥</span>
                <span>Direct Hospital Booking Hub</span>
              </div>
              <div class="space-y-1">
                <button onclick="openHospitalDirectBooking('aravind')" class="w-full text-left p-2 rounded-xl bg-white dark:bg-slate-900 border border-teal-500/20 hover-poppy font-bold text-[11px] block text-teal-700 dark:text-teal-300">
                  👁️ Aravind Eye Hospital Portal →
                </button>
                <button onclick="openHospitalDirectBooking('meenakshi')" class="w-full text-left p-2 rounded-xl bg-white dark:bg-slate-900 border border-teal-500/20 hover-poppy font-bold text-[11px] block text-teal-700 dark:text-teal-300">
                  🩺 Meenakshi Mission Portal →
                </button>
              </div>
            </div>
          </div>

          <!-- Bottom Telemetry Status -->
          <div class="pt-4 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-400 space-y-1">
            <div class="flex items-center justify-between font-mono">
              <span>Security Auth</span>
              <span class="text-emerald-500 font-bold">UIDAI & ABHA Verified</span>
            </div>
            <div class="flex items-center justify-between font-mono">
              <span>Google Maps Grounding</span>
              <span class="text-teal-500 font-bold">Live GPS Lat/Lng</span>
            </div>
          </div>
        </aside>
      `;
    }

    // ACTIVE ROUTE SCREEN RENDERING
    function renderActiveRouteScreen(route, u, t) {
      const p = u.profile;

      // 1. DASHBOARD
      if (route === 'DASHBOARD') {
        const nextAppt = u.appointments.find(a => a.status === 'Confirmed');
        const activePolicy = u.insurancePolicies.find(x => x.isActive);

        return `
          <div class="space-y-6">
            <!-- Hero Patient Header -->
            <div class="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 class="text-3xl font-extrabold tracking-tight">${t.navDashboard}</h2>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Real-time health overview for <span class="font-bold text-slate-800 dark:text-slate-200">${p.fullName}</span> (+91 ${state.activeUserId})</p>
              </div>
              <div class="flex items-center gap-2">
                <button onclick="state.showBookingModal=true;render();" class="btn-theme-poppy px-4 py-2.5 rounded-2xl font-bold text-xs flex items-center gap-1.5">
                  <span>➕</span>
                  <span>${t.bookAppointmentTitle}</span>
                </button>
                <button onclick="state.currentRoute='AI_CHAT';saveState();render();" class="px-4 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-bold hover-poppy">
                  🤖 ${t.navAiChat}
                </button>
              </div>
            </div>

            <!-- Health Snapshot & Biomarkers Preview -->
            <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm card-gradient-hover space-y-4">
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-3">
                  <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-white text-lg btn-theme-poppy">🩺</div>
                  <div>
                    <h3 class="font-extrabold text-base">${t.healthSnapshotTitle}</h3>
                    <p class="text-xs text-slate-500">${t.clickToElaborateHint}</p>
                  </div>
                </div>
                <button onclick="state.currentRoute='HEALTH_SNAPSHOT';saveState();render();" class="text-xs font-bold" style="color: var(--theme-primary);">
                  ${t.navHealthSnapshot} →
                </button>
              </div>

              <!-- Quick Metrics Grid (Click to elaborate) -->
              <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div onclick="openModal('SNAPSHOT', 'bp')" class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 cursor-pointer hover-poppy">
                  <div class="flex items-center justify-between">
                    <span class="text-slate-400 block text-[10px] uppercase font-bold">Blood Pressure</span>
                    <span class="text-[9px] font-extrabold text-emerald-600 bg-emerald-500/10 px-1.5 py-0.5 rounded">Optimal</span>
                  </div>
                  <span class="font-extrabold text-base block mt-1" style="color: var(--theme-primary);">${u.snapshot.bp}</span>
                  <span class="text-[10px] text-slate-400">Resting 12-Lead stable</span>
                </div>
                <div onclick="openModal('SNAPSHOT', 'glucose')" class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 cursor-pointer hover-poppy">
                  <div class="flex items-center justify-between">
                    <span class="text-slate-400 block text-[10px] uppercase font-bold">Fasting Glucose</span>
                    <span class="text-[9px] font-extrabold text-emerald-600 bg-emerald-500/10 px-1.5 py-0.5 rounded">Normal</span>
                  </div>
                  <span class="font-extrabold text-base block mt-1" style="color: var(--theme-primary);">${u.snapshot.fastingSugar}</span>
                  <span class="text-[10px] text-slate-400">Target < 99 mg/dL</span>
                </div>
                <div onclick="openModal('SNAPSHOT', 'hba1c')" class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 cursor-pointer hover-poppy">
                  <div class="flex items-center justify-between">
                    <span class="text-slate-400 block text-[10px] uppercase font-bold">HbA1c (3-Mo Avg)</span>
                    <span class="text-[9px] font-extrabold text-teal-600 bg-teal-500/10 px-1.5 py-0.5 rounded">Controlled</span>
                  </div>
                  <span class="font-extrabold text-base block mt-1" style="color: var(--theme-primary);">${u.snapshot.hba1c}</span>
                  <span class="text-[10px] text-slate-400">HPLC Lab Standard</span>
                </div>
                <div onclick="openModal('SNAPSHOT', 'heartRate')" class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 cursor-pointer hover-poppy">
                  <div class="flex items-center justify-between">
                    <span class="text-slate-400 block text-[10px] uppercase font-bold">Pulse & Rhythm</span>
                    <span class="text-[9px] font-extrabold text-emerald-600 bg-emerald-500/10 px-1.5 py-0.5 rounded">Normal</span>
                  </div>
                  <span class="font-extrabold text-base block mt-1" style="color: var(--theme-primary);">${u.snapshot.pulse}</span>
                  <span class="text-[10px] text-slate-400">Sinus 72 bpm</span>
                </div>
              </div>
            </div>

            <!-- Medical Reminders Banner -->
            <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm card-gradient-hover space-y-4">
              <div class="flex items-center justify-between">
                <div>
                  <h3 class="font-bold text-base flex items-center gap-2">
                    <span>⏰</span>
                    <span>${t.medicalRemindersTitle}</span>
                  </h3>
                  <p class="text-xs text-slate-500">${t.medicalRemindersSubtitle}</p>
                </div>
                <button onclick="state.currentRoute='MEDICINES';saveState();render();" class="text-xs font-bold" style="color: var(--theme-primary);">
                  ${t.navMedicines} →
                </button>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                ${u.medicalReminders.map(rem => `
                  <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
                    <div class="space-y-1">
                      <div class="flex items-center gap-2">
                        <span class="font-extrabold text-xs">${rem.medName}</span>
                        <span class="text-[10px] px-2 py-0.5 rounded-full font-mono font-bold bg-slate-200 dark:bg-slate-700">${rem.dosage}</span>
                      </div>
                      <div class="text-slate-500 text-[11px]">⏰ <span class="font-bold text-slate-700 dark:text-slate-300">${rem.time}</span> · ${rem.slot}</div>
                      <div class="text-[10px] text-slate-400">${rem.instructions}</div>
                    </div>
                    <button onclick="toggleReminderDose('${rem.id}')" 
                      class="px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${rem.taken ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30' : 'btn-theme-poppy'}">
                      ${rem.taken ? `✓ Taken (${rem.takenTime || '08:15 AM'})` : `○ Mark Taken`}
                    </button>
                  </div>
                `).join('')}
              </div>
            </div>

            <!-- Direct Hospital Booking Highlight (Aravind & Meenakshi) -->
            <div class="p-6 rounded-3xl bg-gradient-to-br from-slate-900 to-slate-800 text-white shadow-xl space-y-4">
              <div class="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <span class="px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-teal-500/20 text-teal-300 border border-teal-500/30">
                    Direct Hospital Booking Hub
                  </span>
                  <h3 class="text-lg font-black mt-1">Book Directly at Aravind or Meenakshi Mission</h3>
                  <p class="text-xs text-slate-300">Dedicated appointment portals with verified specialists and instant token slip generation.</p>
                </div>
                <button onclick="state.currentRoute='APPOINTMENTS';state.appointmentsTab='available_hospitals';saveState();render();" class="btn-theme-poppy px-4 py-2 rounded-2xl font-bold text-xs">
                  View All Hospitals →
                </button>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <!-- Aravind Eye Hospital Direct Card -->
                <div class="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 space-y-3 hover-poppy">
                  <div class="flex items-center gap-3">
                    <div class="text-3xl">👁️</div>
                    <div>
                      <h4 class="font-extrabold text-sm text-teal-300">${t.aravindEyeHospital}</h4>
                      <p class="text-[11px] text-slate-300">${t.aravindTagline}</p>
                    </div>
                  </div>
                  <div class="text-xs text-slate-300 space-y-1">
                    <div>👨‍⚕️ <strong>Dr. Aravind Ramanathan</strong> (Cornea & Cataract Specialist)</div>
                    <div>💵 Consultation: ₹500 · Cashless Star Health Approved</div>
                  </div>
                  <button onclick="openHospitalDirectBooking('aravind')" class="w-full py-2 rounded-xl btn-theme-poppy font-extrabold text-xs">
                    ${t.openAravindBooking}
                  </button>
                </div>

                <!-- Meenakshi Mission Direct Card -->
                <div class="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 space-y-3 hover-poppy">
                  <div class="flex items-center gap-3">
                    <div class="text-3xl">🩺</div>
                    <div>
                      <h4 class="font-extrabold text-sm text-cyan-300">${t.meenakshiMission}</h4>
                      <p class="text-[11px] text-slate-300">${t.meenakshiTagline}</p>
                    </div>
                  </div>
                  <div class="text-xs text-slate-300 space-y-1">
                    <div>👩‍⚕️ <strong>Dr. Meenakshi Sundaram</strong> (Diabetology & Internal Med)</div>
                    <div>💵 Consultation: ₹800 · Comprehensive Lab Network</div>
                  </div>
                  <button onclick="openHospitalDirectBooking('meenakshi')" class="w-full py-2 rounded-xl btn-theme-poppy font-extrabold text-xs">
                    ${t.openMeenakshiBooking}
                  </button>
                </div>
              </div>
            </div>

            <!-- Two-Column Section: Upcoming Appointment & Insurance Coverage -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <!-- Upcoming Appointment -->
              <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm card-gradient-hover space-y-4">
                <div class="flex items-center justify-between">
                  <h3 class="font-bold text-sm text-slate-600 dark:text-slate-400">Next Scheduled Visit</h3>
                  <button onclick="state.currentRoute='APPOINTMENTS';saveState();render();" class="text-xs font-bold" style="color: var(--theme-primary);">All Visits (${u.appointments.length}) →</button>
                </div>
                ${nextAppt ? `
                  <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-3 text-xs">
                    <div class="flex items-center justify-between">
                      <div class="font-extrabold text-sm">${nextAppt.doctorName}</div>
                      <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">${nextAppt.status}</span>
                    </div>
                    <div class="text-slate-500">${nextAppt.hospitalOrClinic} · ${nextAppt.department}</div>
                    <div class="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-700">
                      <span class="font-bold">⏰ ${nextAppt.appointmentDate} (${nextAppt.appointmentTime})</span>
                      <button onclick="openModal('APPOINTMENT', '${nextAppt.id}')" class="text-xs font-extrabold" style="color: var(--theme-primary);">
                        Fee & Slip →
                      </button>
                    </div>
                  </div>
                ` : `
                  <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 text-xs text-slate-500">No appointments scheduled.</div>
                `}
              </div>

              <!-- Receipts & Billing Snapshot -->
              <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm card-gradient-hover space-y-4">
                <div class="flex items-center justify-between">
                  <h3 class="font-bold text-sm text-slate-600 dark:text-slate-400">Recent Medical Receipts</h3>
                  <button onclick="state.currentRoute='RECEIPTS';saveState();render();" class="text-xs font-bold" style="color: var(--theme-primary);">All Receipts (${u.receipts.length}) →</button>
                </div>
                <div class="space-y-2 text-xs">
                  ${u.receipts.slice(0, 2).map(r => `
                    <div onclick="openModal('RECEIPT', '${r.id}')" class="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between cursor-pointer hover-poppy">
                      <div>
                        <div class="font-bold truncate">${r.providerName.split(',')[0]}</div>
                        <div class="text-[10px] text-slate-400">${r.date} · ${r.receiptNumber}</div>
                      </div>
                      <div class="text-right">
                        <div class="font-extrabold" style="color: var(--theme-primary);">₹${r.subtotal}</div>
                        <div class="text-[10px] text-emerald-600 font-bold">${r.status.split(' ')[0]}</div>
                      </div>
                    </div>
                  `).join('')}
                </div>
              </div>
            </div>
          </div>
        `;
      }

      // 2. HEALTH SNAPSHOT & BIOMARKERS (DEEP DEFINITION & ELABORATION)
      if (route === 'HEALTH_SNAPSHOT') {
        const metrics = Object.values(SNAPSHOT_METRICS_DETAIL);

        return `
          <div class="space-y-6">
            <div class="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 class="text-2xl font-black tracking-tight">${t.healthSnapshotTitle}</h2>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">${t.healthSnapshotSubtitle}</p>
              </div>
              <button onclick="openModal('SNAPSHOT', 'bp')" class="btn-theme-poppy px-4 py-2 rounded-2xl font-bold text-xs flex items-center gap-1.5">
                <span>🩺</span>
                <span>Open Vitals Guide</span>
              </button>
            </div>

            <!-- Hint banner -->
            <div class="p-4 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-teal-800 dark:text-teal-300 text-xs font-bold flex items-center gap-2">
              <span>💡</span>
              <span>${t.clickToElaborateHint}</span>
            </div>

            <!-- Deep Health Metrics Grid -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              ${metrics.map(m => {
                const title = m.title[state.language] || m.title.en;
                return `
                  <div onclick="openModal('SNAPSHOT', '${m.id}')" 
                    class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 card-gradient-hover cursor-pointer space-y-3">
                    <div class="flex items-center justify-between">
                      <span class="text-slate-400 uppercase text-[10px] font-bold truncate">${title}</span>
                      <span class="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">${m.status}</span>
                    </div>
                    <div>
                      <div class="text-xl font-black tracking-tight" style="color: var(--theme-primary);">${m.value}</div>
                      <div class="text-[11px] text-slate-500 font-medium mt-0.5">${m.badge}</div>
                    </div>
                    <!-- Reference Meter Mini Bar -->
                    <div class="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div class="h-full rounded-full" style="width: ${m.gaugePercent}%; background: var(--theme-gradient);"></div>
                    </div>
                    <div class="pt-1 flex items-center justify-between text-[10px] text-slate-400 font-semibold border-t border-slate-100 dark:border-slate-800">
                      <span>Tap to elaborate</span>
                      <span style="color: var(--theme-primary);">Details →</span>
                    </div>
                  </div>
                `;
              }).join('')}
            </div>

            <!-- Additional Clinical Parameters (Allergies, Chronic Conditions, Vaccinations) -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div class="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 card-gradient-hover space-y-2">
                <div class="text-slate-400 uppercase font-bold text-[10px]">Known Drug & Food Allergies</div>
                <div class="font-extrabold text-sm text-red-600">${u.snapshot.allergies}</div>
                <p class="text-slate-500 text-[11px]">Strict caution on beta-lactam antibiotics. Hospital allergy band active.</p>
              </div>

              <div class="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 card-gradient-hover space-y-2">
                <div class="text-slate-400 uppercase font-bold text-[10px]">Active Chronic Conditions</div>
                <div class="font-extrabold text-sm text-teal-600">${u.snapshot.recentDiagnosis}</div>
                <p class="text-slate-500 text-[11px]">Regular follow-up with Dr. Meenakshi Sundaram & Dr. Sivakumar.</p>
              </div>

              <div class="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 card-gradient-hover space-y-2">
                <div class="text-slate-400 uppercase font-bold text-[10px]">Immunization & Booster History</div>
                <div class="font-extrabold text-sm text-emerald-600">${u.snapshot.vaccinationStatus}</div>
                <p class="text-slate-500 text-[11px]">All national adult booster certificates archived in Health Records.</p>
              </div>
            </div>

            <!-- Medical Reminders Timeline Section -->
            <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm card-gradient-hover space-y-4">
              <div class="flex items-center justify-between">
                <div>
                  <h3 class="font-bold text-base flex items-center gap-2">
                    <span>⏰</span>
                    <span>${t.medicalRemindersTitle}</span>
                  </h3>
                  <p class="text-xs text-slate-500">${t.medicalRemindersSubtitle}</p>
                </div>
                <button onclick="state.currentRoute='MEDICINES';saveState();render();" class="text-xs font-bold" style="color: var(--theme-primary);">
                  Manage Prescriptions →
                </button>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                ${u.medicalReminders.map(rem => `
                  <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
                    <div class="space-y-1">
                      <div class="flex items-center gap-2">
                        <span class="font-bold text-xs">${rem.medName}</span>
                        <span class="text-[10px] px-2 py-0.5 rounded-full font-mono bg-slate-200 dark:bg-slate-700">${rem.dosage}</span>
                      </div>
                      <div class="text-slate-500 text-[11px]">⏰ <span class="font-bold text-slate-700 dark:text-slate-300">${rem.time}</span> · ${rem.slot}</div>
                      <div class="text-[10px] text-slate-400">${rem.instructions}</div>
                    </div>
                    <button onclick="toggleReminderDose('${rem.id}')" 
                      class="px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${rem.taken ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30' : 'btn-theme-poppy'}">
                      ${rem.taken ? `✓ Taken (${rem.takenTime || '08:15 AM'})` : `○ Mark Taken`}
                    </button>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>
        `;
      }

      // 3. APPOINTMENTS (WITH DEDICATED DIRECT BOOKING TABS FOR ARAVIND & MEENAKSHI)
      if (route === 'APPOINTMENTS') {
        return `
          <div class="space-y-6">
            <div class="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 class="text-2xl font-black tracking-tight">${t.navAppointments} (${u.appointments.length})</h2>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">${t.bookAppointmentSubtitle}</p>
              </div>
              <div class="flex items-center gap-2">
                <button onclick="openHospitalDirectBooking('aravind')" class="btn-theme-poppy px-4 py-2.5 rounded-2xl font-bold text-xs flex items-center gap-1.5">
                  <span>👁️</span>
                  <span>Book at Aravind Eye Hospital</span>
                </button>
                <button onclick="openHospitalDirectBooking('meenakshi')" class="btn-theme-poppy px-4 py-2.5 rounded-2xl font-bold text-xs flex items-center gap-1.5">
                  <span>🩺</span>
                  <span>Book at Meenakshi Mission</span>
                </button>
              </div>
            </div>

            <!-- Tab Switcher: Scheduled Appointments vs Available Hospitals & Direct Booking Hub -->
            <div class="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
              <button onclick="state.appointmentsTab='scheduled';saveState();render();" 
                class="px-4 py-2 rounded-2xl text-xs font-extrabold transition-all ${state.appointmentsTab === 'scheduled' ? 'btn-theme-poppy shadow-sm' : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'}">
                📅 ${t.scheduledAppointmentsTab} (${u.appointments.length})
              </button>
              <button onclick="state.appointmentsTab='available_hospitals';saveState();render();" 
                class="px-4 py-2 rounded-2xl text-xs font-extrabold transition-all ${state.appointmentsTab === 'available_hospitals' ? 'btn-theme-poppy shadow-sm' : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'}">
                🏥 ${t.availableHospitalsTab} (Direct Portals)
              </button>
            </div>

            ${state.appointmentsTab === 'available_hospitals' ? `
              <!-- AVAILABLE HOSPITALS & DIRECT PORTALS (Aravind & Meenakshi) -->
              <div class="space-y-6">
                <div class="p-4 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-xs text-teal-900 dark:text-teal-200">
                  <div class="font-extrabold text-sm mb-1">Direct Entry Hospital Portals</div>
                  <div>Clicking <strong>Aravind Eye Hospital</strong> directly opens Aravind's ophthalmologists & services. Clicking <strong>Meenakshi Mission</strong> opens Meenakshi's cardiology & diabetology slots.</div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <!-- Aravind Eye Hospital Full Showcase Card -->
                  <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover space-y-4">
                    <div class="flex items-center justify-between">
                      <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl btn-theme-poppy">👁️</div>
                        <div>
                          <h3 class="font-extrabold text-base">${t.aravindEyeHospital}</h3>
                          <p class="text-xs text-slate-500">Madurai · Chennai · Coimbatore Network</p>
                        </div>
                      </div>
                      <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-teal-500/15 text-teal-700 dark:text-teal-300">NABH Accredited</span>
                    </div>

                    <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">${t.aravindTagline}</p>

                    <div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 space-y-2 text-xs">
                      <div class="font-bold text-[11px] text-slate-400 uppercase">Available Ophthalmologists</div>
                      <div class="space-y-1.5">
                        <div class="flex items-center justify-between">
                          <div>
                            <div class="font-bold">Dr. Aravind Ramanathan</div>
                            <div class="text-[10px] text-slate-500">Chief Cornea & Refractive Surgeon</div>
                          </div>
                          <span class="text-[10px] font-mono font-bold text-emerald-600">₹500 Fee</span>
                        </div>
                        <div class="flex items-center justify-between">
                          <div>
                            <div class="font-bold">Dr. N. Venkatesh Prajna</div>
                            <div class="text-[10px] text-slate-500">Director & Senior Vitreo-Retinal Surgeon</div>
                          </div>
                          <span class="text-[10px] font-mono font-bold text-emerald-600">₹600 Fee</span>
                        </div>
                      </div>
                    </div>

                    <div class="flex items-center justify-between text-xs font-semibold text-slate-500 pt-1">
                      <span>✓ Cashless Star Health / HDFC</span>
                      <span>✓ Instant Token Generation</span>
                    </div>

                    <button onclick="openHospitalDirectBooking('aravind')" class="w-full py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs shadow-md">
                      ${t.openAravindBooking}
                    </button>
                  </div>

                  <!-- Meenakshi Mission Full Showcase Card -->
                  <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover space-y-4">
                    <div class="flex items-center justify-between">
                      <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl btn-theme-poppy">🩺</div>
                        <div>
                          <h3 class="font-extrabold text-base">${t.meenakshiMission}</h3>
                          <p class="text-xs text-slate-500">Lake Area, Melur Road, Madurai</p>
                        </div>
                      </div>
                      <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/15 text-cyan-700 dark:text-cyan-300">1000-Bed Tertiary</span>
                    </div>

                    <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">${t.meenakshiTagline}</p>

                    <div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 space-y-2 text-xs">
                      <div class="font-bold text-[11px] text-slate-400 uppercase">Available Specialists</div>
                      <div class="space-y-1.5">
                        <div class="flex items-center justify-between">
                          <div>
                            <div class="font-bold">Dr. Meenakshi Sundaram</div>
                            <div class="text-[10px] text-slate-500">Chief Diabetologist & Metabolic Physician</div>
                          </div>
                          <span class="text-[10px] font-mono font-bold text-emerald-600">₹800 Fee</span>
                        </div>
                        <div class="flex items-center justify-between">
                          <div>
                            <div class="font-bold">Dr. R. Sivakumar</div>
                            <div class="text-[10px] text-slate-500">Head of Interventional Cardiology</div>
                          </div>
                          <span class="text-[10px] font-mono font-bold text-emerald-600">₹900 Fee</span>
                        </div>
                      </div>
                    </div>

                    <div class="flex items-center justify-between text-xs font-semibold text-slate-500 pt-1">
                      <span>✓ 24/7 Trauma Emergency</span>
                      <span>✓ Full Metabolic & ECHO Lab</span>
                    </div>

                    <button onclick="openHospitalDirectBooking('meenakshi')" class="w-full py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs shadow-md">
                      ${t.openMeenakshiBooking}
                    </button>
                  </div>

                  <!-- Apollo Speciality Card -->
                  <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover space-y-4">
                    <div class="flex items-center justify-between">
                      <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl btn-theme-poppy">🏥</div>
                        <div>
                          <h3 class="font-extrabold text-base">${t.apolloSpeciality}</h3>
                          <p class="text-xs text-slate-500">Greams Road, Chennai</p>
                        </div>
                      </div>
                      <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/15 text-purple-700 dark:text-purple-300">JCI Accredited</span>
                    </div>
                    <p class="text-xs text-slate-600 dark:text-slate-300">Advanced neurology, cardiovascular surgery, and robotic clinical interventions.</p>
                    <button onclick="openHospitalDirectBooking('apollo')" class="w-full py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs">
                      ${t.openApolloBooking}
                    </button>
                  </div>

                  <!-- Dr. Lal PathLabs Card -->
                  <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover space-y-4">
                    <div class="flex items-center justify-between">
                      <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl btn-theme-poppy">🧪</div>
                        <div>
                          <h3 class="font-extrabold text-base">${t.lalPathlabs}</h3>
                          <p class="text-xs text-slate-500">NABL Accredited Diagnostics</p>
                        </div>
                      </div>
                      <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-700 dark:text-amber-300">Lab & Blood</span>
                    </div>
                    <p class="text-xs text-slate-600 dark:text-slate-300">HbA1c HPLC, Lipid profiles, Thyroid panels, and home sample collection.</p>
                    <button onclick="openHospitalDirectBooking('lal')" class="w-full py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs">
                      ${t.openLalBooking}
                    </button>
                  </div>
                </div>
              </div>
            ` : `
              <!-- SCHEDULED APPOINTMENTS LIST (With Cancel, Fee Breakdown, Insurance Status, Download Slip) -->
              <div class="space-y-4">
                ${u.appointments.length === 0 ? `
                  <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-10 text-center space-y-3">
                    <div class="text-4xl">📅</div>
                    <div class="font-bold text-sm">No appointments scheduled.</div>
                    <button onclick="openHospitalDirectBooking('aravind')" class="btn-theme-poppy px-4 py-2 rounded-xl text-xs font-bold">
                      Book Doctor Appointment
                    </button>
                  </div>
                ` : u.appointments.map(appt => `
                  <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover space-y-4">
                    <div class="flex flex-wrap items-center justify-between gap-3">
                      <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl font-bold btn-theme-poppy shrink-0">
                          ${appt.hospitalKey === 'aravind' ? '👁️' : appt.hospitalKey === 'meenakshi' ? '🩺' : '👨‍⚕️'}
                        </div>
                        <div>
                          <div class="flex items-center gap-2">
                            <h4 class="font-black text-base">${appt.doctorName}</h4>
                            <span class="text-xs font-mono font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800">${appt.tokenNumber || 'TK-42'}</span>
                          </div>
                          <p class="text-xs text-slate-500 font-semibold">${appt.hospitalOrClinic} · ${appt.department}</p>
                        </div>
                      </div>

                      <div class="flex items-center gap-2">
                        <span class="px-3 py-1 rounded-full text-xs font-extrabold ${appt.status === 'Cancelled' ? 'bg-red-500/15 text-red-600' : 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'}">
                          ${appt.status === 'Cancelled' ? t.appointmentCancelledBadge : t.appointmentConfirmedBadge}
                        </span>
                        <span class="text-xs font-mono px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                          ${appt.bookingRef}
                        </span>
                      </div>
                    </div>

                    <!-- Clinical Details & Schedule Grid -->
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl">
                      <div>
                        <span class="text-slate-400 block text-[10px] uppercase font-bold">Appointment Schedule</span>
                        <span class="font-extrabold text-slate-800 dark:text-slate-200">${appt.appointmentDate} (${appt.appointmentTime})</span>
                      </div>
                      <div>
                        <span class="text-slate-400 block text-[10px] uppercase font-bold">Consultation Mode</span>
                        <span class="font-bold" style="color: var(--theme-primary);">${appt.consultationType}</span>
                      </div>
                      <div>
                        <span class="text-slate-400 block text-[10px] uppercase font-bold">Insurance Status</span>
                        <span class="font-bold ${appt.insuranceApplicable ? 'text-emerald-600' : 'text-slate-500'}">
                          ${appt.billingStatus || 'Cashless Pre-Auth'}
                        </span>
                      </div>
                    </div>

                    <!-- Reason -->
                    <div class="text-xs text-slate-600 dark:text-slate-300">
                      <strong>Reason / Symptoms:</strong> ${appt.reasonForVisit}
                    </div>

                    <!-- Actions Bar (Download Slip, View Fee Breakdown, Cancel Appointment) -->
                    <div class="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                      <div class="flex items-center gap-2">
                        <button onclick="downloadPrintSlip('${appt.bookingRef}')" class="px-4 py-2 rounded-xl btn-theme-poppy text-xs font-bold shadow-sm flex items-center gap-1.5">
                          <span>${t.downloadSlipButton}</span>
                        </button>
                        <button onclick="openModal('APPOINTMENT', '${appt.id}')" class="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold hover-poppy">
                          ${t.viewAppointmentDetails}
                        </button>
                      </div>

                      ${appt.status !== 'Cancelled' ? `
                        <button onclick="cancelAppointment('${appt.id}')" class="px-4 py-2 rounded-xl border border-red-300 dark:border-red-900/40 text-red-600 text-xs font-bold hover:bg-red-50 dark:hover:bg-red-950/30">
                          ${t.cancelAppointment}
                        </button>
                      ` : `
                        <span class="text-xs font-bold text-red-500 font-mono">Cancelled & Refunded</span>
                      `}
                    </div>
                  </div>
                `).join('')}
              </div>
            `}
          </div>
        `;
      }

      // 4. MEDICATIONS (TAKEN TICK MARKS, EXACT TIMES, DETAILED ELABORATION)
      if (route === 'MEDICINES') {
        return `
          <div class="space-y-6">
            <div class="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 class="text-2xl font-black tracking-tight">${t.navMedicines} (${u.medicines.length})</h2>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Prescription timetable with exact hours, intake confirmation, and refill alerts.</p>
              </div>
              <button onclick="openModal('ADD_MEDICINE')" class="btn-theme-poppy px-4 py-2.5 rounded-2xl font-bold text-xs">
                ${t.addMedication}
              </button>
            </div>

            <!-- Refill Warning Card (If Any Medicine Supply is Low) -->
            ${u.medicines.some(m => m.refillNeeded) ? `
              <div class="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 flex items-center justify-between text-xs">
                <div class="flex items-center gap-2.5">
                  <span class="text-xl">⚠️</span>
                  <div>
                    <span class="font-extrabold">${t.refillAlertTitle}:</span>
                    <span>${t.refillWarning}</span>
                  </div>
                </div>
                <button onclick="alert('Order placed with MedPlus Pharmacy partner!');" class="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs">
                  Reorder from MedPlus
                </button>
              </div>
            ` : ''}

            <!-- Daily Medication Schedule List -->
            <div class="space-y-4">
              ${u.medicines.map(med => `
                <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover space-y-4">
                  <div class="flex flex-wrap items-center justify-between gap-3">
                    <div class="flex items-center gap-3">
                      <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl btn-theme-poppy shrink-0">
                        💊
                      </div>
                      <div>
                        <div class="flex items-center gap-2">
                          <h4 class="font-black text-base cursor-pointer hover:underline" onclick="openModal('MEDICINE', '${med.id}')">${med.medicineName}</h4>
                          <span class="px-2 py-0.5 rounded-md text-xs font-mono font-bold bg-slate-100 dark:bg-slate-800">${med.dosage}</span>
                        </div>
                        <p class="text-xs text-slate-500 font-semibold">${med.salt}</p>
                      </div>
                    </div>

                    <!-- Taken or Not Toggle Button with Tick Mark -->
                    <div class="flex items-center gap-2">
                      <button onclick="toggleMedicationDose('${med.id}')" 
                        class="px-4 py-2 rounded-2xl text-xs font-extrabold flex items-center gap-1.5 transition-all ${med.takenToday ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/40 shadow-sm' : 'btn-theme-poppy'}">
                        <span>${med.takenToday ? '✓' : '○'}</span>
                        <span>${med.takenToday ? `${t.takenBadge} (${med.takenTodayTime || '08:15 AM'})` : t.markAsTaken}</span>
                      </button>
                    </div>
                  </div>

                  <!-- Details Grid -->
                  <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl">
                    <div>
                      <span class="text-slate-400 block text-[10px] uppercase font-bold">${t.timeDue}</span>
                      <span class="font-extrabold text-slate-800 dark:text-slate-200">⏰ ${med.exactTime}</span>
                    </div>
                    <div>
                      <span class="text-slate-400 block text-[10px] uppercase font-bold">${t.frequencyLabel}</span>
                      <span class="font-bold text-slate-700 dark:text-slate-300">${med.frequency}</span>
                    </div>
                    <div>
                      <span class="text-slate-400 block text-[10px] uppercase font-bold">${t.remainingSupply}</span>
                      <span class="font-bold ${med.refillNeeded ? 'text-amber-600' : 'text-emerald-600'}">
                        ${med.remainingSupply} Tablets ${med.refillNeeded ? '(Refill Alert)' : '(Safe)'}
                      </span>
                    </div>
                  </div>

                  <!-- Instructions & Food Advisory -->
                  <div class="text-xs space-y-1 text-slate-600 dark:text-slate-300">
                    <div><strong>Instructions:</strong> ${med.instructions}</div>
                    <div><strong>${t.foodInstructions}:</strong> ${med.foodAdvisory}</div>
                    <div class="text-[11px] text-slate-400">Prescribed by: ${med.prescribedBy}</div>
                  </div>

                  <!-- Click to Elaborate Details Button -->
                  <div class="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                    <button onclick="openModal('MEDICINE', '${med.id}')" class="font-bold" style="color: var(--theme-primary);">
                      View Pharmacology, Indications & Side Effects →
                    </button>
                    <span class="text-[11px] text-slate-400 font-mono">Status: ${med.status}</span>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        `;
      }

      // 5. RECEIPTS & INVOICES (DETAILED BILLING, 80D TAX, ADD MORE RECEIPTS)
      if (route === 'RECEIPTS') {
        const totalAmount = u.receipts.reduce((acc, r) => acc + r.subtotal, 0);

        return `
          <div class="space-y-6">
            <div class="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 class="text-2xl font-black tracking-tight">${t.receiptsTitle} (${u.receipts.length})</h2>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">${t.receiptsSubtitle}</p>
              </div>
              <button onclick="openModal('ADD_RECEIPT')" class="btn-theme-poppy px-4 py-2.5 rounded-2xl font-bold text-xs flex items-center gap-1.5">
                <span>➕</span>
                <span>${t.addReceiptButton}</span>
              </button>
            </div>

            <!-- Tax Summary Banner -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div class="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 card-gradient-hover space-y-1">
                <span class="text-slate-400 uppercase font-bold text-[10px]">Total Medical Billed</span>
                <span class="text-2xl font-black block" style="color: var(--theme-primary);">₹${totalAmount.toLocaleString()}</span>
                <span class="text-slate-400 text-[10px]">Across ${u.receipts.length} itemized invoices</span>
              </div>
              <div class="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 card-gradient-hover space-y-1">
                <span class="text-slate-400 uppercase font-bold text-[10px]">Income Tax Sec 80D</span>
                <span class="text-2xl font-black block text-emerald-600">100% Eligible</span>
                <span class="text-slate-400 text-[10px]">Full PAN & GST verification</span>
              </div>
              <div class="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 card-gradient-hover space-y-1">
                <span class="text-slate-400 uppercase font-bold text-[10px]">Cashless TPA Settled</span>
                <span class="text-2xl font-black block text-teal-600">₹5,200</span>
                <span class="text-slate-400 text-[10px]">Direct hospital settlement</span>
              </div>
            </div>

            <!-- Itemized Receipts Grid (Full Neat Breakdown) -->
            <div class="space-y-4">
              ${u.receipts.map(rcp => `
                <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover space-y-4">
                  <div class="flex flex-wrap items-center justify-between gap-3">
                    <div class="flex items-center gap-3">
                      <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl btn-theme-poppy shrink-0">
                        🧾
                      </div>
                      <div>
                        <div class="flex items-center gap-2">
                          <h4 class="font-black text-base cursor-pointer hover:underline" onclick="openModal('RECEIPT', '${rcp.id}')">${rcp.providerName}</h4>
                          <span class="px-2 py-0.5 rounded-md text-xs font-mono font-bold bg-slate-100 dark:bg-slate-800">${rcp.receiptNumber}</span>
                        </div>
                        <p class="text-xs text-slate-500 font-semibold">${rcp.category} · ${rcp.taxInvoiceId}</p>
                      </div>
                    </div>

                    <div class="text-right">
                      <div class="text-xl font-black" style="color: var(--theme-primary);">₹${rcp.subtotal}</div>
                      <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">
                        ${rcp.status}
                      </span>
                    </div>
                  </div>

                  <!-- Itemized Breakdown Table -->
                  <div class="overflow-x-auto">
                    <table class="w-full text-xs text-left">
                      <thead class="bg-slate-50 dark:bg-slate-800/60 text-slate-400 uppercase text-[10px] font-bold">
                        <tr>
                          <th class="p-2.5 rounded-l-xl">Description</th>
                          <th class="p-2.5 text-center">Qty</th>
                          <th class="p-2.5 text-right">Rate</th>
                          <th class="p-2.5 text-right rounded-r-xl">Total</th>
                        </tr>
                      </thead>
                      <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                        ${rcp.items.map(it => `
                          <tr>
                            <td class="p-2.5 font-medium">${it.name}</td>
                            <td class="p-2.5 text-center">${it.qty}</td>
                            <td class="p-2.5 text-right font-mono">₹${it.rate}</td>
                            <td class="p-2.5 text-right font-bold font-mono">₹${it.amount}</td>
                          </tr>
                        `).join('')}
                      </tbody>
                    </table>
                  </div>

                  <!-- Billing Totals & Payment Method -->
                  <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 text-xs">
                    <div>
                      <span class="text-slate-400 block text-[10px] uppercase font-bold">${t.paymentMethodLabel}</span>
                      <span class="font-extrabold text-slate-800 dark:text-slate-200">${rcp.paymentMethod}</span>
                    </div>
                    <div>
                      <span class="text-slate-400 block text-[10px] uppercase font-bold">${t.insuranceClaimedLabel}</span>
                      <span class="font-bold text-teal-600">₹${rcp.insuranceClaimed || 0}</span>
                    </div>
                    <div>
                      <span class="text-slate-400 block text-[10px] uppercase font-bold">${t.patientPaidLabel}</span>
                      <span class="font-bold text-emerald-600">₹${rcp.patientPaid}</span>
                    </div>
                  </div>

                  <!-- Actions -->
                  <div class="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                    <span class="text-emerald-600 font-bold text-[11px]">✓ ${t.taxDeductionEligible}</span>
                    <div class="flex items-center gap-2">
                      <button onclick="openModal('RECEIPT', '${rcp.id}')" class="font-bold text-xs" style="color: var(--theme-primary);">
                        View Detailed Invoice Slip →
                      </button>
                    </div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        `;
      }

      // 6. GUARDIAN & CAREGIVER MANAGEMENT (FILLED WITHOUT GAPS + ADD GUARDIAN CARD)
      if (route === 'GUARDIAN' || route === 'GUARDIAN_OVERVIEW') {
        return `
          <div class="space-y-6">
            <div class="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 class="text-2xl font-black tracking-tight">${t.guardianPageTitle}</h2>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">${t.guardianPageSubtitle}</p>
              </div>
              <button onclick="openModal('ADD_GUARDIAN')" class="btn-theme-poppy px-4 py-2.5 rounded-2xl font-bold text-xs flex items-center gap-1.5">
                <span>➕</span>
                <span>${t.addNewGuardian}</span>
              </button>
            </div>

            <!-- Emergency SOS Dispatch Banner -->
            <div class="p-6 rounded-3xl bg-gradient-to-r from-red-600 to-rose-700 text-white shadow-lg space-y-3">
              <div class="flex flex-wrap items-center justify-between gap-4">
                <div class="space-y-1">
                  <div class="flex items-center gap-2">
                    <span class="text-2xl">🚨</span>
                    <h3 class="font-black text-lg">${t.emergencySosTitle}</h3>
                  </div>
                  <p class="text-xs text-red-100 max-w-xl">
                    Broadcasts your real-time GPS coordinates to all authorized guardians and dials 108 Emergency Medical Services.
                  </p>
                </div>
                <button onclick="alert('🚨 SOS DISPATCH SIMULATION:\nLive GPS broadcasted to Kavitha Ramesh (+91 9840123456) and Suresh Kumar!\nEmergency 108 trauma line alerted.');" 
                  class="px-5 py-3 rounded-2xl bg-white text-red-600 font-black text-xs hover:bg-red-50 shadow-md hover-poppy">
                  ${t.triggerSosButton}
                </button>
              </div>
            </div>

            <!-- Packed 2x2 Caregiver Network Grid (Zero Empty Gaps) -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
              ${u.guardians.map(g => `
                <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover space-y-4">
                  <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                      <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl btn-theme-poppy shrink-0">
                        👩
                      </div>
                      <div>
                        <div class="flex items-center gap-2">
                          <h4 class="font-extrabold text-base">${g.name}</h4>
                          <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">
                            ${g.statusBadge || 'Verified'}
                          </span>
                        </div>
                        <p class="text-xs text-slate-500 font-semibold">${g.relationship}</p>
                      </div>
                    </div>
                  </div>

                  <div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 space-y-1.5 text-xs">
                    <div class="flex items-center justify-between">
                      <span class="text-slate-400 font-bold uppercase text-[10px]">Mobile Contact</span>
                      <span class="font-mono font-bold">+91 ${g.phoneNumber}</span>
                    </div>
                    <div class="flex items-center justify-between">
                      <span class="text-slate-400 font-bold uppercase text-[10px]">Authorized Permissions</span>
                      <span class="font-bold text-teal-600">Records, Appointments, SOS</span>
                    </div>
                  </div>

                  <p class="text-xs text-slate-600 dark:text-slate-300">${g.notes}</p>

                  <div class="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <a href="tel:+91${g.phoneNumber}" class="flex-1 py-2 rounded-xl text-center btn-theme-poppy font-bold text-xs">
                      ${t.callGuardian}
                    </a>
                    <button onclick="alert('Health update sent via WhatsApp to ' + '${g.name}');" class="flex-1 py-2 rounded-xl text-center bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 font-bold text-xs hover-poppy">
                      ${t.whatsappGuardian}
                    </button>
                  </div>
                </div>
              `).join('')}

              <!-- Dependent Health Monitor Card (Filling slot without gap) -->
              ${u.dependents.map(dep => `
                <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover space-y-4">
                  <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                      <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl btn-theme-poppy shrink-0">
                        👴
                      </div>
                      <div>
                        <div class="flex items-center gap-2">
                          <h4 class="font-extrabold text-base">${dep.name}</h4>
                          <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-500/15 text-teal-700 dark:text-teal-300">
                            ${dep.bloodGroup}
                          </span>
                        </div>
                        <p class="text-xs text-slate-500 font-semibold">${dep.relationship}</p>
                      </div>
                    </div>
                  </div>

                  <div class="grid grid-cols-2 gap-2 text-xs">
                    <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                      <div class="text-[9px] text-slate-400 uppercase font-bold">Vitals Sync</div>
                      <div class="font-extrabold text-xs text-teal-600 mt-0.5">BP ${dep.bp}</div>
                    </div>
                    <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60">
                      <div class="text-[9px] text-slate-400 uppercase font-bold">Compliance</div>
                      <div class="font-extrabold text-xs text-emerald-600 mt-0.5">${dep.complianceRate}</div>
                    </div>
                  </div>

                  <div class="text-xs text-slate-600 dark:text-slate-300">
                    <div><strong>Physician:</strong> ${dep.attendingDoctor}</div>
                    <div><strong>Next Visit:</strong> ${dep.nextCheckup}</div>
                  </div>

                  <button onclick="alert('Syncing geriatric sensor vitals for Mr. K. Narayanan...');" class="w-full py-2.5 rounded-xl btn-theme-poppy font-bold text-xs">
                    Sync Vitals with Hospital →
                  </button>
                </div>
              `).join('')}

              <!-- Add New Guardian / Dependent Card (Filling the Next Empty Box) -->
              <div onclick="openModal('ADD_GUARDIAN')" 
                class="bg-slate-50/50 dark:bg-slate-900/40 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-3xl p-8 flex flex-col items-center justify-center text-center cursor-pointer hover:border-teal-500 transition-all space-y-3 hover-poppy">
                <div class="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl btn-theme-poppy">
                  ➕
                </div>
                <div>
                  <h4 class="font-extrabold text-sm">${t.addNewGuardian}</h4>
                  <p class="text-xs text-slate-400 max-w-xs mt-1">Register a family member, medical proxy, or elder dependent into this slot.</p>
                </div>
                <span class="px-4 py-2 rounded-xl btn-theme-poppy font-bold text-xs mt-2">
                  Add to Network
                </span>
              </div>
            </div>
          </div>
        `;
      }

      // 7. PROFILE (EXPANSIVE IDENTITY: AADHAAR, PAN, ABHA, DIGITAL HEALTH CARD)
      if (route === 'PROFILE') {
        return `
          <div class="space-y-6">
            <div class="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 class="text-2xl font-black tracking-tight">${t.profileTitle}</h2>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">${t.profileSubtitle}</p>
              </div>
              <button onclick="openModal('EDIT_PROFILE')" class="btn-theme-poppy px-4 py-2.5 rounded-2xl font-bold text-xs flex items-center gap-1.5">
                <span>✏️</span>
                <span>${t.editProfileButton}</span>
              </button>
            </div>

            <!-- Digital Health Card Hero Visual -->
            <div class="p-8 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-800 to-teal-950 text-white shadow-2xl space-y-6 border border-teal-500/30">
              <div class="flex flex-wrap items-center justify-between gap-4">
                <div class="flex items-center gap-4">
                  <div class="w-16 h-16 rounded-3xl flex items-center justify-center text-3xl btn-theme-poppy shadow-lg">
                    👨‍⚕️
                  </div>
                  <div>
                    <div class="flex items-center gap-2">
                      <h3 class="text-2xl font-black">${p.fullName}</h3>
                      <span class="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">✓ UIDAI Verified</span>
                    </div>
                    <div class="text-xs text-slate-300 font-mono mt-0.5">+91 ${p.phoneNumber} · ${p.email}</div>
                  </div>
                </div>

                <!-- Digital Ayushman Bharat QR Badge -->
                <div class="p-3 bg-white/10 rounded-2xl backdrop-blur-md border border-white/20 text-right">
                  <div class="text-[10px] text-teal-300 uppercase tracking-widest font-bold">ABHA Digital Health ID</div>
                  <div class="text-base font-black font-mono tracking-wider">${p.abhaId}</div>
                  <div class="text-[10px] text-slate-300 font-mono">${p.abhaAddress}</div>
                </div>
              </div>

              <!-- Demographics Strip -->
              <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs pt-4 border-t border-white/10">
                <div>
                  <span class="text-slate-400 block text-[10px] uppercase font-bold">Age & Gender</span>
                  <span class="font-extrabold text-sm">${p.age} Years · ${p.gender}</span>
                </div>
                <div>
                  <span class="text-slate-400 block text-[10px] uppercase font-bold">${t.bloodGroupLabel}</span>
                  <span class="font-extrabold text-sm text-teal-300">${p.bloodGroup}</span>
                </div>
                <div>
                  <span class="text-slate-400 block text-[10px] uppercase font-bold">Clinical Height / Weight</span>
                  <span class="font-extrabold text-sm">178 cm · 74 kg (BMI 23.4)</span>
                </div>
                <div>
                  <span class="text-slate-400 block text-[10px] uppercase font-bold">Emergency Caregiver</span>
                  <span class="font-extrabold text-sm text-cyan-300">${p.emergencyContactName} (+91 ${p.emergencyContactPhone})</span>
                </div>
              </div>
            </div>

            <!-- National Government Credentials & Identity Dossier -->
            <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover space-y-4">
              <h3 class="font-black text-base">Verified Government Identification & Credentials</h3>
              
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <!-- Aadhaar Card -->
                <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-2">
                  <div class="flex items-center justify-between">
                    <span class="text-slate-400 uppercase font-bold text-[10px]">${t.aadhaarCardLabel}</span>
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">UIDAI Verified ✓</span>
                  </div>
                  <div class="text-lg font-black font-mono tracking-widest text-slate-800 dark:text-slate-200">${p.aadhaarNumber}</div>
                  <div class="text-[11px] text-slate-500">Biometric OTP Authentication active. Linked to ABHA health record locker.</div>
                </div>

                <!-- PAN Card -->
                <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-2">
                  <div class="flex items-center justify-between">
                    <span class="text-slate-400 uppercase font-bold text-[10px]">${t.panCardLabel}</span>
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-500/15 text-teal-700 dark:text-teal-300">Income Tax Active ✓</span>
                  </div>
                  <div class="text-lg font-black font-mono tracking-widest text-slate-800 dark:text-slate-200">${p.panNumber}</div>
                  <div class="text-[11px] text-slate-500">Form 80D medical tax exemption certificate automatically mapped to receipts.</div>
                </div>

                <!-- ABHA Digital Health Account -->
                <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-2">
                  <div class="flex items-center justify-between">
                    <span class="text-slate-400 uppercase font-bold text-[10px]">${t.abhaIdLabel}</span>
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/15 text-cyan-700 dark:text-cyan-300">NDHM Certified ✓</span>
                  </div>
                  <div class="text-lg font-black font-mono text-slate-800 dark:text-slate-200">${p.abhaId}</div>
                  <div class="text-[11px] text-slate-500">Address: <span class="font-bold font-mono">${p.abhaAddress}</span> (Ayushman Bharat Digital Mission)</div>
                </div>

                <!-- Organ Donor Status -->
                <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-2">
                  <div class="flex items-center justify-between">
                    <span class="text-slate-400 uppercase font-bold text-[10px]">${t.organDonorLabel}</span>
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/15 text-purple-700 dark:text-purple-300">Donor Badge ✓</span>
                  </div>
                  <div class="font-extrabold text-sm text-slate-800 dark:text-slate-200">${t.registeredDonor}</div>
                  <div class="text-[11px] text-slate-500">Authorized for Cornea (Aravind Eye Bank) and Solid Organs upon medical criteria.</div>
                </div>
              </div>
            </div>

            <!-- Address & Contact -->
            <div class="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 card-gradient-hover text-xs space-y-2">
              <div class="font-bold text-slate-400 uppercase text-[10px]">Permanent Residential Address</div>
              <div class="font-extrabold text-sm text-slate-800 dark:text-slate-200">${p.address}</div>
              <div class="text-slate-500">Verified against Aadhaar address proof. Last verified: 2026-01-15.</div>
            </div>
          </div>
        `;
      }

      // 8. AI CHAT
      if (route === 'AI_CHAT') {
        return `
          <div class="space-y-4 flex flex-col h-[75vh]">
            <div class="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 shrink-0">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-xl btn-theme-poppy">🤖</div>
                <div>
                  <h2 class="text-lg font-black">${t.navAiChat}</h2>
                  <p class="text-[11px] text-slate-500">Gemini 3.8 Flash · Google Maps Grounding · Multi-Language</p>
                </div>
              </div>
            </div>

            <!-- Messages Thread -->
            <div id="chat-thread-container" class="flex-1 overflow-y-auto space-y-3 p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 custom-sidebar-scroll">
              ${u.chatMessages.map(msg => `
                <div class="flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}">
                  <div class="max-w-xl p-4 rounded-3xl text-xs space-y-2 ${msg.role === 'user' ? 'btn-theme-poppy text-white rounded-br-none' : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-bl-none'}">
                    <p class="leading-relaxed whitespace-pre-wrap">${msg.text}</p>
                    ${msg.placeLinks && msg.placeLinks.length > 0 ? `
                      <div class="space-y-1.5 pt-2 border-t border-slate-200/40 dark:border-slate-700/60">
                        <div class="text-[10px] font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400">Google Maps Verified Facilities:</div>
                        ${msg.placeLinks.map(pl => `
                          <a href="${pl.uri}" target="_blank" rel="noopener noreferrer" class="block p-2 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-700 font-bold hover:underline">
                            📍 ${pl.title} — <span class="text-[10px] font-normal text-slate-500">${pl.address}</span>
                          </a>
                        `).join('')}
                      </div>
                    ` : ''}
                    <div class="text-[9px] text-slate-400 text-right">${msg.timestamp}</div>
                  </div>
                </div>
              `).join('')}
              ${isChatLoading ? `
                <div class="flex justify-start">
                  <div class="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-teal-600 animate-pulse flex items-center gap-2">
                    <span>✨</span>
                    <span>MedTrace AI is consulting clinical knowledge & maps...</span>
                  </div>
                </div>
              ` : ''}
            </div>

            <!-- Quick Suggestions -->
            <div class="flex flex-wrap gap-2 shrink-0">
              <button onclick="sendAiChatMessage('${t.quickPromptMaps}')" class="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover-poppy text-xs font-bold">
                ${t.quickPromptMaps}
              </button>
              <button onclick="sendAiChatMessage('${t.quickPromptVitals}')" class="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover-poppy text-xs font-bold">
                ${t.quickPromptVitals}
              </button>
              <button onclick="sendAiChatMessage('${t.quickPromptInsurance}')" class="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover-poppy text-xs font-bold">
                ${t.quickPromptInsurance}
              </button>
            </div>

            <!-- Input Box -->
            <form onsubmit="event.preventDefault(); const input=document.getElementById('chat-input-field'); if(input && input.value) { sendAiChatMessage(input.value); input.value=''; }" class="flex gap-2 shrink-0">
              <input id="chat-input-field" type="text" placeholder="${t.aiPlaceholder}" class="flex-1 px-4 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-teal-500" />
              <button type="submit" class="px-5 py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs shadow-md">
                ${t.aiSendButton}
              </button>
            </form>
          </div>
        `;
      }

      // 9. INSURANCE
      if (route === 'INSURANCE') {
        return `
          <div class="space-y-6">
            <div class="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 class="text-2xl font-black tracking-tight">${t.navInsurance}</h2>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Active health coverage with cashless network hospitals across India.</p>
              </div>
            </div>

            <!-- Active Policy Card -->
            ${u.insurancePolicies.map(pol => `
              <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover space-y-4">
                <div class="flex flex-wrap items-center justify-between gap-3">
                  <div class="flex items-center gap-3">
                    <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl btn-theme-poppy shrink-0">🛡️</div>
                    <div>
                      <h4 class="font-extrabold text-base">${pol.providerName}</h4>
                      <p class="text-xs text-slate-500 font-mono font-bold">${pol.policyNumber}</p>
                    </div>
                  </div>
                  <span class="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">
                    Active (₹15 Lakhs Cover)
                  </span>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 text-xs">
                  <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-bold">Policy Type</span>
                    <span class="font-bold">${pol.policyType}</span>
                  </div>
                  <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-bold">Cashless Hospital Network</span>
                    <span class="font-bold text-teal-600">Aravind, Meenakshi & Apollo</span>
                  </div>
                  <div>
                    <span class="text-slate-400 block text-[10px] uppercase font-bold">Validity</span>
                    <span class="font-bold">${pol.startDate} to ${pol.expiryDate}</span>
                  </div>
                </div>

                <div class="text-xs text-slate-600 dark:text-slate-300">
                  <strong>Covered Services:</strong> ${pol.coveredServices}
                </div>
              </div>
            `).join('')}
          </div>
        `;
      }

      // 10. HEALTH RECORDS
      if (route === 'HEALTH_RECORDS') {
        return `
          <div class="space-y-6">
            <div class="flex items-center justify-between">
              <h2 class="text-2xl font-black tracking-tight">${t.navHealthRecords} (${u.records.length})</h2>
              <button onclick="alert('File upload dialog opened.');" class="btn-theme-poppy px-4 py-2.5 rounded-2xl font-bold text-xs">+ Upload Report</button>
            </div>
            ${u.records.map(r => `
              <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 card-gradient-hover flex flex-wrap items-center justify-between gap-4 text-xs">
                <div class="space-y-1">
                  <div class="font-bold text-sm">📄 ${r.fileName}</div>
                  <div class="text-slate-500 font-mono">${r.recordType} · ${r.fileSize} · ${r.uploadDate}</div>
                  <div class="text-[11px]" style="color: var(--theme-primary);">${r.appointmentLabel}</div>
                </div>
                <button onclick="alert(r.contentPreview);" class="btn-theme-poppy px-4 py-2 rounded-xl font-bold text-xs">
                  View Clinical Document
                </button>
              </div>
            `).join('')}
          </div>
        `;
      }

      // 11. NEARBY HOSPITALS & MAPS
      if (route === 'NEARBY_HOSPITALS') {
        return `
          <div class="space-y-6">
            <h2 class="text-2xl font-black tracking-tight">${t.navNearbyHospitals}</h2>
            <p class="text-xs text-slate-500">Google Maps Grounded 24/7 emergency centers and specialty clinics in your vicinity.</p>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              ${DOCTORS_LIST.map(d => `
                <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 card-gradient-hover space-y-3 text-xs">
                  <div class="font-bold text-sm text-slate-800 dark:text-slate-200">${d.hospital}</div>
                  <div class="text-slate-500 font-semibold">${d.name} (${d.specialty})</div>
                  <div class="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                    <span class="text-amber-500 font-bold">${d.rating}</span>
                    <a href="https://www.google.com/maps/search/${encodeURIComponent(d.hospital)}" target="_blank" rel="noopener noreferrer" class="font-extrabold text-xs" style="color: var(--theme-primary);">
                      Open Maps ↗
                    </a>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        `;
      }

      // 12. SETTINGS
      return `
        <div class="space-y-6 max-w-4xl">
          <div>
            <h2 class="text-2xl font-black tracking-tight">${t.navSettings}</h2>
            <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">${t.themeColorSubtitle}</p>
          </div>

          <!-- Color Palettes Picker (Dark and Light Modes) -->
          <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover space-y-4">
            <div>
              <h3 class="font-bold text-sm">${t.themeColorTitle}</h3>
              <p class="text-xs text-slate-500">Choose your favorite accent and hover tone:</p>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
              ${Object.keys(THEME_PALETTES).map(k => {
                const pal = THEME_PALETTES[k];
                const isSelected = state.themeColor === k;
                return `
                  <button onclick="setThemeColor('${k}')" 
                    class="p-4 rounded-2xl border text-left transition-all hover-poppy ${isSelected ? 'border-2 border-slate-900 dark:border-white shadow-md' : 'border-slate-200 dark:border-slate-800'}" 
                    style="background: ${isSelected ? pal.subtle : 'transparent'};">
                    <div class="w-8 h-8 rounded-full mb-2 flex items-center justify-center text-white text-xs font-bold" style="background-color: ${pal.primary};">
                      ${isSelected ? '✓' : ''}
                    </div>
                    <div class="font-bold text-xs">${pal.name}</div>
                  </button>
                `;
              }).join('')}
            </div>
          </div>

          <!-- Dark / Light Mode Toggle -->
          <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 card-gradient-hover flex items-center justify-between">
            <div>
              <h3 class="font-bold text-sm">Dark / Light Interface Appearance</h3>
              <p class="text-xs text-slate-500">Toggle high-contrast dark theme mode</p>
            </div>
            <button onclick="toggleDarkMode()" class="px-5 py-2.5 rounded-2xl btn-theme-poppy font-bold text-xs">
              ${state.isDarkMode ? 'Switch to Light Mode ☀️' : 'Switch to Dark Mode 🌙'}
            </button>
          </div>

          <!-- Sign Out -->
          <div class="pt-4">
            <button onclick="state.activeUserId=null;saveState();render();" class="px-6 py-3 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md hover-poppy">
              🚪 ${t.logoutButton}
            </button>
          </div>
        </div>
      `;
    }

    // MODAL DIALOGS (Health Elaboration, Medicine Detail, Appointment Fee Breakdown, Receipts Detail, Add Caregiver, Add Receipt, Edit Profile)
    function renderActiveModal(u, t) {
      if (!state.activeModal) return '';
      const { type, data } = state.activeModal;

      // 1. HEALTH SNAPSHOT ELABORATION MODAL
      if (type === 'SNAPSHOT') {
        const m = SNAPSHOT_METRICS_DETAIL[data] || SNAPSHOT_METRICS_DETAIL.bp;
        const title = m.title[state.language] || m.title.en;
        const advice = m.doctorNotes[state.language] || m.doctorNotes.en;

        return `
          <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
            <div class="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl overflow-y-auto max-h-[90vh]">
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-3">
                  <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-white text-xl btn-theme-poppy">🩺</div>
                  <div>
                    <h3 class="text-base font-black">${title}</h3>
                    <p class="text-xs text-slate-500">${m.badge}</p>
                  </div>
                </div>
                <button onclick="closeModal()" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold text-xs">✕</button>
              </div>

              <!-- Main Reading & Status -->
              <div class="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between">
                <div>
                  <span class="text-xs text-slate-400 font-bold uppercase">Current Reading</span>
                  <div class="text-3xl font-black mt-1" style="color: var(--theme-primary);">${m.value}</div>
                </div>
                <span class="px-3 py-1 rounded-full text-xs font-black bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30">
                  ${m.status}
                </span>
              </div>

              <!-- Reference Range Gauge -->
              <div class="space-y-2 text-xs">
                <span class="text-slate-400 font-bold uppercase text-[10px]">${t.referenceRange}</span>
                <div class="p-3 rounded-xl bg-slate-100 dark:bg-slate-800 font-mono text-slate-700 dark:text-slate-300">
                  ${m.rangeText}
                </div>
              </div>

              <!-- Attending Physician Advice -->
              <div class="p-4 rounded-2xl bg-teal-500/10 border border-teal-500/20 space-y-1.5 text-xs text-teal-900 dark:text-teal-200">
                <div class="font-extrabold flex items-center gap-1.5">
                  <span>👨‍⚕️</span>
                  <span>${t.doctorAdviceTitle}</span>
                </div>
                <p class="leading-relaxed">${advice}</p>
              </div>

              <!-- Historical Test Trends -->
              <div class="space-y-2 text-xs">
                <span class="text-slate-400 font-bold uppercase text-[10px]">${t.historicalLogs}</span>
                <div class="space-y-1.5">
                  ${m.historical.map(h => `
                    <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between">
                      <div>
                        <div class="font-mono font-bold">${h.date}</div>
                        <div class="text-[10px] text-slate-400">${h.context}</div>
                      </div>
                      <div class="font-black text-sm" style="color: var(--theme-primary);">${h.val}</div>
                    </div>
                  `).join('')}
                </div>
              </div>

              <button onclick="closeModal()" class="w-full py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs shadow-md">
                ${t.closeModal}
              </button>
            </div>
          </div>
        `;
      }

      // 2. MEDICINE DETAIL MODAL
      if (type === 'MEDICINE') {
        const med = u.medicines.find(m => m.id === data) || u.medicines[0];
        return `
          <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
            <div class="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl overflow-y-auto max-h-[90vh]">
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-3">
                  <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-white text-xl btn-theme-poppy">💊</div>
                  <div>
                    <h3 class="text-base font-black">${med.medicineName}</h3>
                    <p class="text-xs text-slate-500">${med.dosage} · ${med.salt}</p>
                  </div>
                </div>
                <button onclick="closeModal()" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold text-xs">✕</button>
              </div>

              <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 space-y-2 text-xs">
                <div class="flex items-center justify-between">
                  <span class="text-slate-400 uppercase font-bold text-[10px]">Exact Dosage Timing</span>
                  <span class="font-extrabold text-teal-600">⏰ ${med.exactTime}</span>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-slate-400 uppercase font-bold text-[10px]">Today's Status</span>
                  <span class="font-extrabold ${med.takenToday ? 'text-emerald-600' : 'text-amber-600'}">
                    ${med.takenToday ? `✓ Taken at ${med.takenTodayTime || '08:15 AM'}` : '○ Pending Intake'}
                  </span>
                </div>
              </div>

              <div class="space-y-3 text-xs text-slate-600 dark:text-slate-300">
                <div>
                  <strong class="block text-slate-800 dark:text-slate-200 mb-1">Prescription Instructions:</strong>
                  <p>${med.instructions}</p>
                </div>
                <div>
                  <strong class="block text-slate-800 dark:text-slate-200 mb-1">Dietary & Food Warnings:</strong>
                  <p>${med.foodAdvisory}</p>
                </div>
                <div>
                  <strong class="block text-slate-800 dark:text-slate-200 mb-1">Side Effects to Monitor:</strong>
                  <p>${med.sideEffects}</p>
                </div>
                <div class="text-[11px] text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
                  Prescribed by: ${med.prescribedBy}
                </div>
              </div>

              <div class="flex gap-2">
                <button onclick="toggleMedicationDose('${med.id}'); closeModal();" class="flex-1 py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs">
                  ${med.takenToday ? 'Mark as Not Taken' : 'Mark as Taken Today ✓'}
                </button>
                <button onclick="closeModal()" class="px-5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 font-bold text-xs">
                  Close
                </button>
              </div>
            </div>
          </div>
        `;
      }

      // 3. APPOINTMENT ELABORATION & ITEMIZED FEE BREAKDOWN MODAL
      if (type === 'APPOINTMENT') {
        const appt = u.appointments.find(a => a.id === data) || u.appointments[0];
        return `
          <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
            <div class="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl overflow-y-auto max-h-[90vh]">
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-3">
                  <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-white text-xl btn-theme-poppy">👨‍⚕️</div>
                  <div>
                    <h3 class="text-base font-black">${appt.doctorName}</h3>
                    <p class="text-xs text-slate-500">${appt.hospitalOrClinic} · Token: ${appt.tokenNumber || 'TK-42'}</p>
                  </div>
                </div>
                <button onclick="closeModal()" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold text-xs">✕</button>
              </div>

              <!-- Itemized Fee Structure -->
              <div class="space-y-3">
                <h4 class="font-black text-sm">${t.feeStructureTitle}</h4>
                <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 divide-y divide-slate-200 dark:divide-slate-700 text-xs">
                  <div class="flex justify-between py-2">
                    <span class="text-slate-500">${t.doctorFee}</span>
                    <span class="font-mono font-bold">₹${appt.consultationFee || 500}</span>
                  </div>
                  <div class="flex justify-between py-2">
                    <span class="text-slate-500">${t.registrationFee}</span>
                    <span class="font-mono font-bold">₹${appt.registrationFee || 150}</span>
                  </div>
                  <div class="flex justify-between py-2">
                    <span class="text-slate-500">${t.diagnosticAddon}</span>
                    <span class="font-mono font-bold">₹${appt.diagnosticFee || 450}</span>
                  </div>
                  <div class="flex justify-between py-2">
                    <span class="text-slate-500">${t.taxesFee}</span>
                    <span class="font-mono font-bold">₹0 (Health Exempt)</span>
                  </div>
                  <div class="flex justify-between py-2.5 font-extrabold text-sm">
                    <span>${t.totalGross}</span>
                    <span class="font-mono" style="color: var(--theme-primary);">₹${appt.grossAmount || 1100}</span>
                  </div>
                </div>
              </div>

              <!-- Insurance Coverage & Cashless Status -->
              <div class="p-4 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-xs space-y-2">
                <div class="font-extrabold text-teal-800 dark:text-teal-300 flex items-center justify-between">
                  <span>${t.insuranceCoverage}</span>
                  <span class="px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-700 dark:text-teal-300">Pre-Approved</span>
                </div>
                <div class="text-slate-600 dark:text-slate-300">
                  Policy: <strong>${appt.insurancePolicyName || 'Star Health Cashless'}</strong>
                </div>
                <div class="flex justify-between pt-1 font-bold">
                  <span>Insurance Covered Portion:</span>
                  <span class="text-emerald-600 font-mono">₹${appt.insuranceCoveredAmount || 1100} (100% Cashless)</span>
                </div>
                <div class="flex justify-between font-bold">
                  <span>${t.patientCopay}:</span>
                  <span class="font-mono" style="color: var(--theme-primary);">₹${appt.patientCopayAmount || 0}</span>
                </div>
              </div>

              <!-- Buttons -->
              <div class="flex gap-2">
                <button onclick="downloadPrintSlip('${appt.bookingRef}')" class="flex-1 py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs shadow-md">
                  ${t.downloadSlipButton}
                </button>
                ${appt.status !== 'Cancelled' ? `
                  <button onclick="cancelAppointment('${appt.id}'); closeModal();" class="px-5 py-3 rounded-2xl border border-red-300 text-red-600 font-bold text-xs hover:bg-red-50">
                    ${t.cancelAppointment}
                  </button>
                ` : ''}
              </div>
            </div>
          </div>
        `;
      }

      // 4. DETAILED RECEIPT / INVOICE MODAL
      if (type === 'RECEIPT') {
        const rcp = u.receipts.find(r => r.id === data) || u.receipts[0];
        return `
          <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
            <div class="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-5 shadow-2xl overflow-y-auto max-h-[90vh]">
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 class="text-base font-black">${rcp.providerName}</h3>
                  <p class="text-xs text-slate-500 font-mono">${rcp.receiptNumber} · ${rcp.date}</p>
                </div>
                <button onclick="closeModal()" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold text-xs">✕</button>
              </div>

              <!-- Tax & Category -->
              <div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between text-xs">
                <div>
                  <span class="text-slate-400 block text-[10px] uppercase font-bold">GSTIN Registration</span>
                  <span class="font-mono font-bold">${rcp.taxInvoiceId}</span>
                </div>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300">
                  Income Tax 80D Approved
                </span>
              </div>

              <!-- Itemized Table -->
              <div class="space-y-2">
                <span class="text-slate-400 uppercase font-bold text-[10px]">Itemized Services</span>
                <table class="w-full text-xs text-left divide-y divide-slate-100 dark:divide-slate-800">
                  <thead>
                    <tr class="text-slate-400 text-[10px]">
                      <th class="py-2">Item</th>
                      <th class="py-2 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${rcp.items.map(it => `
                      <tr>
                        <td class="py-2">${it.name} (Qty ${it.qty})</td>
                        <td class="py-2 text-right font-mono font-bold">₹${it.amount}</td>
                      </tr>
                    `).join('')}
                    <tr class="font-black text-sm pt-2">
                      <td class="py-2">Total Amount Billed</td>
                      <td class="py-2 text-right font-mono" style="color: var(--theme-primary);">₹${rcp.subtotal}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div class="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 text-xs space-y-1">
                <div><strong>Payment Method:</strong> ${rcp.paymentMethod}</div>
                <div><strong>Transaction ID:</strong> <span class="font-mono">${rcp.transactionRef || 'TXN-99120'}</span></div>
              </div>

              <div class="flex gap-2">
                <button onclick="alert('Tax Invoice PDF downloaded!'); closeModal();" class="flex-1 py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs">
                  ${t.downloadInvoice}
                </button>
                <button onclick="closeModal()" class="px-5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 font-bold text-xs">
                  Close
                </button>
              </div>
            </div>
          </div>
        `;
      }

      // 5. ADD GUARDIAN / DEPENDENT MODAL
      if (type === 'ADD_GUARDIAN') {
        return `
          <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
            <div class="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl">
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h3 class="text-base font-black">${t.addNewGuardian}</h3>
                <button onclick="closeModal()" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold text-xs">✕</button>
              </div>

              <form onsubmit="
                event.preventDefault();
                const name = document.getElementById('new-g-name').value;
                const rel = document.getElementById('new-g-rel').value;
                const phone = document.getElementById('new-g-phone').value;
                if(!name || !phone) return;
                const u = ensureUserBucket(state.activeUserId);
                u.guardians.push({
                  id: 'g-' + Date.now(),
                  name: name,
                  relationship: rel,
                  phoneNumber: phone,
                  isPhoneVerified: true,
                  statusBadge: 'Verified Caregiver',
                  notes: 'Registered authorized proxy with emergency and appointment access.'
                });
                saveState();
                closeModal();
              " class="space-y-3 text-xs">
                <div>
                  <label class="block font-bold text-slate-500 mb-1">Full Name</label>
                  <input id="new-g-name" type="text" required placeholder="e.g. Meena Raman" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none" />
                </div>
                <div>
                  <label class="block font-bold text-slate-500 mb-1">Relationship</label>
                  <select id="new-g-rel" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    <option>Spouse</option>
                    <option>Parent / Guardian</option>
                    <option>Child / Dependent</option>
                    <option>Sibling</option>
                    <option>Primary Physician Proxy</option>
                  </select>
                </div>
                <div>
                  <label class="block font-bold text-slate-500 mb-1">10-Digit Mobile Number</label>
                  <input id="new-g-phone" type="tel" pattern="[0-9]{10}" required placeholder="9876543210" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 focus:outline-none" />
                </div>
                <div class="pt-2 flex gap-2">
                  <button type="submit" class="flex-1 py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs">
                    Save to Network
                  </button>
                  <button type="button" onclick="closeModal()" class="px-5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 font-bold text-xs">
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        `;
      }

      // 6. ADD RECEIPT MODAL
      if (type === 'ADD_RECEIPT') {
        return `
          <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
            <div class="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl">
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h3 class="text-base font-black">${t.addReceiptButton}</h3>
                <button onclick="closeModal()" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold text-xs">✕</button>
              </div>

              <form onsubmit="
                event.preventDefault();
                const prov = document.getElementById('new-r-prov').value;
                const amt = parseFloat(document.getElementById('new-r-amt').value) || 500;
                const cat = document.getElementById('new-r-cat').value;
                const u = ensureUserBucket(state.activeUserId);
                u.receipts.unshift({
                  id: 'rcp-' + Date.now(),
                  receiptNumber: 'INV-NEW-' + Math.floor(1000 + Math.random()*9000),
                  date: new Date().toISOString().split('T')[0],
                  providerName: prov,
                  taxInvoiceId: 'GSTIN33AUTO' + Math.floor(10000 + Math.random()*90000),
                  category: cat,
                  items: [{ name: cat, qty: 1, rate: amt, gst: 0, amount: amt }],
                  subtotal: amt,
                  cgst: 0,
                  sgst: 0,
                  insuranceClaimed: 0,
                  patientPaid: amt,
                  paymentMethod: 'UPI / Direct',
                  status: 'Paid',
                  section80DEligible: true,
                  transactionRef: 'TXN-' + Date.now()
                });
                saveState();
                closeModal();
              " class="space-y-3 text-xs">
                <div>
                  <label class="block font-bold text-slate-500 mb-1">Hospital / Clinic / Pharmacy Name</label>
                  <input id="new-r-prov" type="text" required placeholder="e.g. Aravind Eye Hospital / MedPlus" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
                </div>
                <div>
                  <label class="block font-bold text-slate-500 mb-1">Total Bill Amount (INR)</label>
                  <input id="new-r-amt" type="number" required placeholder="1200" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
                </div>
                <div>
                  <label class="block font-bold text-slate-500 mb-1">Category</label>
                  <select id="new-r-cat" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    <option>Doctor Consultation</option>
                    <option>Diagnostics & Lab Tests</option>
                    <option>Pharmacy Prescription Refill</option>
                    <option>Hospital Daycare & Surgery</option>
                  </select>
                </div>
                <div class="pt-2 flex gap-2">
                  <button type="submit" class="flex-1 py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs">
                    Save Receipt
                  </button>
                  <button type="button" onclick="closeModal()" class="px-5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 font-bold text-xs">
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        `;
      }

      // 7. EDIT PROFILE MODAL
      if (type === 'EDIT_PROFILE') {
        const p = u.profile;
        return `
          <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
            <div class="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl overflow-y-auto max-h-[90vh]">
              <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h3 class="text-base font-black">${t.editProfileButton}</h3>
                <button onclick="closeModal()" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold text-xs">✕</button>
              </div>

              <form onsubmit="
                event.preventDefault();
                const u = ensureUserBucket(state.activeUserId);
                u.profile.fullName = document.getElementById('edit-p-name').value;
                u.profile.aadhaarNumber = document.getElementById('edit-p-aadhaar').value;
                u.profile.panNumber = document.getElementById('edit-p-pan').value;
                u.profile.abhaId = document.getElementById('edit-p-abha').value;
                u.profile.address = document.getElementById('edit-p-addr').value;
                u.profile.emergencyContactPhone = document.getElementById('edit-p-emg').value;
                saveState();
                closeModal();
              " class="space-y-3 text-xs">
                <div>
                  <label class="block font-bold text-slate-500 mb-1">Full Name</label>
                  <input id="edit-p-name" type="text" value="${p.fullName}" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
                </div>
                <div class="grid grid-cols-2 gap-3">
                  <div>
                    <label class="block font-bold text-slate-500 mb-1">Aadhaar (UIDAI)</label>
                    <input id="edit-p-aadhaar" type="text" value="${p.aadhaarNumber}" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
                  </div>
                  <div>
                    <label class="block font-bold text-slate-500 mb-1">PAN Card</label>
                    <input id="edit-p-pan" type="text" value="${p.panNumber}" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
                  </div>
                </div>
                <div>
                  <label class="block font-bold text-slate-500 mb-1">ABHA Health ID (Ayushman Bharat)</label>
                  <input id="edit-p-abha" type="text" value="${p.abhaId}" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
                </div>
                <div>
                  <label class="block font-bold text-slate-500 mb-1">Address</label>
                  <input id="edit-p-addr" type="text" value="${p.address}" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
                </div>
                <div>
                  <label class="block font-bold text-slate-500 mb-1">Emergency Caregiver Contact Phone</label>
                  <input id="edit-p-emg" type="tel" value="${p.emergencyContactPhone}" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
                </div>
                <div class="pt-2 flex gap-2">
                  <button type="submit" class="flex-1 py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs">
                    ${t.saveProfileButton}
                  </button>
                  <button type="button" onclick="closeModal()" class="px-5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 font-bold text-xs">
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        `;
      }

      return '';
    }

    // DIRECT HOSPITAL BOOKING MODAL (Supports Aravind & Meenakshi Locked Portals)
    function renderBookingModal(t) {
      const lock = state.bookingHospitalLock; // 'aravind' or 'meenakshi' or null
      const doctors = lock ? DOCTORS_LIST.filter(d => d.hospitalKey === lock) : DOCTORS_LIST;
      const initialDoc = doctors[0];

      return `
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div class="w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl overflow-y-auto max-h-[90vh]">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-xl btn-theme-poppy">
                  ${lock === 'aravind' ? '👁️' : lock === 'meenakshi' ? '🩺' : '🏥'}
                </div>
                <div>
                  <h3 class="text-base font-black">
                    ${lock === 'aravind' ? 'Aravind Eye Hospital Direct Portal' : lock === 'meenakshi' ? 'Meenakshi Mission Hospital Direct Portal' : t.bookAppointmentTitle}
                  </h3>
                  <p class="text-xs text-slate-500">
                    ${lock === 'aravind' ? 'Specialized Cataract, Retina & Cornea Care' : lock === 'meenakshi' ? 'Cardiology, Internal Medicine & Diabetology' : t.bookAppointmentSubtitle}
                  </p>
                </div>
              </div>
              <button onclick="state.showBookingModal=false;state.bookingHospitalLock=null;render();" class="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500 font-bold text-xs">✕</button>
            </div>

            <form onsubmit="
              event.preventDefault();
              const docId = document.getElementById('book-doc-select').value;
              const doc = DOCTORS_LIST.find(d => d.id === docId) || DOCTORS_LIST[0];
              const dateVal = document.getElementById('book-date-input').value || 'Oct 22, 2026';
              const timeVal = document.getElementById('book-time-select').value || '10:30 AM';
              const modeVal = document.getElementById('book-mode-select').value;
              const reasonVal = document.getElementById('book-reason-input').value || 'Routine Follow-up & Evaluation';
              const notifyG = document.getElementById('book-guardian-sync').checked;

              const u = ensureUserBucket(state.activeUserId);
              const ref = 'APT-2026-' + (doc.hospitalKey || 'GEN').toUpperCase() + '-' + Math.floor(1000 + Math.random()*9000);
              const tok = 'TK-' + Math.floor(10 + Math.random()*80);

              u.appointments.unshift({
                id: 'appt-' + Date.now(),
                bookingRef: ref,
                tokenNumber: tok,
                hospitalKey: doc.hospitalKey,
                doctorName: doc.name,
                hospitalOrClinic: doc.hospital,
                department: doc.specialty,
                appointmentDate: dateVal,
                appointmentTime: timeVal,
                consultationType: modeVal,
                reasonForVisit: reasonVal,
                status: 'Confirmed',
                sharedWithGuardian: notifyG,
                consultationFee: doc.consultationFee,
                registrationFee: doc.registrationFee,
                diagnosticFee: doc.diagnosticFee,
                grossAmount: doc.consultationFee + doc.registrationFee + doc.diagnosticFee,
                insuranceApplicable: true,
                insuranceCoveredAmount: doc.consultationFee + doc.registrationFee + doc.diagnosticFee,
                patientCopayAmount: 0,
                insurancePolicyName: 'Star Health Cashless Approved (#SH-' + Math.floor(10000+Math.random()*90000) + ')',
                billingStatus: 'Cashless Token Issued'
              });

              logActivity('Booked slot with ' + doc.name + ' at ' + doc.hospital, 'Appointments');
              saveState();
              state.showBookingModal = false;
              state.bookingHospitalLock = null;
              render();
              alert(t.appointmentBookedSuccess + ' ' + ref + ' (Token ' + tok + ')');
            " class="space-y-4 text-xs">

              <!-- Hospital Pre-selection Indicator -->
              <div class="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                <span class="text-[10px] text-slate-400 uppercase font-bold block">Hospital / Center</span>
                <span class="font-extrabold text-sm" style="color: var(--theme-primary);">
                  ${lock === 'aravind' ? 'Aravind Eye Hospital (Dedicated Portal)' : lock === 'meenakshi' ? 'Meenakshi Mission Hospital (Dedicated Portal)' : 'Multi-Hospital General Registry'}
                </span>
              </div>

              <!-- Specialist Doctor Select (Filtered to this hospital) -->
              <div>
                <label class="block font-bold text-slate-600 dark:text-slate-400 mb-1">${t.selectDoctorLabel}</label>
                <select id="book-doc-select" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold">
                  ${doctors.map(d => `
                    <option value="${d.id}">${d.name} — ${d.specialty} (Fee: ₹${d.consultationFee})</option>
                  `).join('')}
                </select>
              </div>

              <!-- Date & Slot -->
              <div class="grid grid-cols-2 gap-3">
                <div>
                  <label class="block font-bold text-slate-600 dark:text-slate-400 mb-1">${t.appointmentDateLabel}</label>
                  <input id="book-date-input" type="date" value="2026-10-22" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold" />
                </div>
                <div>
                  <label class="block font-bold text-slate-600 dark:text-slate-400 mb-1">${t.appointmentTimeLabel}</label>
                  <select id="book-time-select" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold">
                    <option>09:00 AM</option>
                    <option selected>10:30 AM</option>
                    <option>11:45 AM</option>
                    <option>02:30 PM</option>
                    <option>04:00 PM</option>
                  </select>
                </div>
              </div>

              <!-- Consultation Mode -->
              <div>
                <label class="block font-bold text-slate-600 dark:text-slate-400 mb-1">${t.consultationTypeLabel}</label>
                <select id="book-mode-select" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <option>In-Person Hospital OPD Visit</option>
                  <option>HD Video Teleconsultation</option>
                  <option>Priority Express Consultation</option>
                </select>
              </div>

              <!-- Reason -->
              <div>
                <label class="block font-bold text-slate-600 dark:text-slate-400 mb-1">${t.reasonLabel}</label>
                <input id="book-reason-input" type="text" placeholder="e.g. Eye vision blurriness / Quarterly diabetic checkup" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />
              </div>

              <!-- Guardian Sync Checkbox -->
              <div class="flex items-center gap-2">
                <input id="book-guardian-sync" type="checkbox" checked class="w-4 h-4 rounded text-teal-600" />
                <label for="book-guardian-sync" class="text-xs text-slate-600 dark:text-slate-400 font-medium">
                  ${t.guardianNotifyLabel}
                </label>
              </div>

              <!-- Confirm Buttons -->
              <div class="pt-2 flex gap-2">
                <button type="submit" class="flex-1 py-3 rounded-2xl btn-theme-poppy font-extrabold text-xs shadow-md">
                  ${t.confirmBookingButton}
                </button>
                <button type="button" onclick="state.showBookingModal=false;state.bookingHospitalLock=null;render();" class="px-5 py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 font-bold text-xs">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      `;
    }

    // BIOMETRIC DIALOG
    function renderBiometricDialog(t) {
      if (!biometricModal) return '';
      return `
        <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div class="w-full max-w-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div class="w-16 h-16 mx-auto rounded-3xl flex items-center justify-center text-3xl btn-theme-poppy biometric-pulse">🫆</div>
            <h3 class="font-extrabold text-base">${t.biometricLoginButton}</h3>
            <p class="text-xs text-slate-500">Scan registered fingerprint or use camera face verification</p>
            <div class="space-y-2">
              <button onclick="state.activeUserId='9840123456';biometricModal=null;saveState();render();" class="w-full py-3 rounded-2xl btn-theme-poppy font-bold text-xs">
                Simulate Successful Biometric Login
              </button>
              <button onclick="biometricModal=null;render();" class="w-full py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-500">
                Cancel
              </button>
            </div>
          </div>
        </div>
      `;
    }

    // AUTH SCREEN
    function renderAuthScreen(app, t) {
      app.innerHTML = `
        <div class="min-h-screen flex items-center justify-center p-4 bg-slate-50 dark:bg-slate-950">
          <div class="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 space-y-6 shadow-xl card-gradient-hover">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-3">
                <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl font-black btn-theme-poppy">⚕️</div>
                <div>
                  <h1 class="text-xl font-black">${t.appName}</h1>
                  <p class="text-xs text-slate-500 font-semibold">${t.tagline}</p>
                </div>
              </div>
              ${renderLanguageBar(t)}
            </div>

            <div class="space-y-1">
              <h2 class="text-lg font-bold">${t.loginTitle}</h2>
              <p class="text-xs text-slate-500">${t.loginSubtitle}</p>
            </div>

            <form onsubmit="
              event.preventDefault();
              const phone = document.getElementById('auth-phone').value;
              if(phone && phone.length === 10) {
                state.activeUserId = phone;
                ensureUserBucket(phone);
                saveState();
                render();
              } else {
                alert('Please enter a valid 10-digit mobile number.');
              }
            " class="space-y-4 text-xs">
              <div>
                <label class="block font-bold text-slate-600 dark:text-slate-400 mb-1">${t.phoneNumberLabel}</label>
                <div class="flex gap-2">
                  <span class="px-3.5 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold text-xs flex items-center">+91</span>
                  <input id="auth-phone" type="tel" pattern="[0-9]{10}" value="9840123456" required placeholder="${t.phonePlaceholder}" class="flex-1 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold focus:outline-none" />
                </div>
              </div>

              <button type="submit" class="w-full py-3.5 rounded-2xl btn-theme-poppy font-extrabold text-xs shadow-md">
                ${t.verifyOtpButton} (Demo PIN: Instant)
              </button>
            </form>

            <div class="pt-2 text-center">
              <button onclick="biometricModal={ phone: '9840123456' }; render();" class="text-xs font-bold" style="color: var(--theme-primary);">
                🫆 ${t.biometricLoginButton}
              </button>
            </div>
          </div>
        </div>
      `;
    }

    // Initialize state & start application
    loadState();
    render();
  </script>
</body>
</html>
'''

with open('/app/applet/index.html', 'w', encoding='utf-8') as f:
    f.write(html_code)

print("Generated /app/applet/index.html successfully. Size:", len(html_code))
